import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../providers/reels_provider.dart';
import '../../models/reel_model.dart';


// ─────────────────────────────────────────────────────────────────────────────
// ReelsScreen — parent screen
// ─────────────────────────────────────────────────────────────────────────────

class ReelsScreen extends StatefulWidget {
  const ReelsScreen({super.key});

  @override
  State<ReelsScreen> createState() => _ReelsScreenState();
}

class _ReelsScreenState extends State<ReelsScreen> {
  late PageController _pageController;
  int _currentIndex = 0;
  bool _isLiked = false;
  bool _isBookmarked = false;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
      ),
    );
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ReelsProvider>().loadReels();
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ReelsProvider>();

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // ── Loading ──────────────────────────────────────────────────────
          if (provider.isLoading)
            const Center(
              child: CircularProgressIndicator(color: Colors.white),
            )

          // ── Empty ────────────────────────────────────────────────────────
          else if (provider.reels.isEmpty)
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.video_library_outlined,
                    size: 72,
                    color: Colors.white.withOpacity(0.3),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No reels available',
                    style: AppTextStyles.body.copyWith(
                      color: Colors.white.withOpacity(0.5),
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            )

          // ── Reels PageView ───────────────────────────────────────────────
          else
            PageView.builder(
              controller: _pageController,
              scrollDirection: Axis.vertical,
              itemCount: provider.reels.length,
              onPageChanged: (index) {
                setState(() {
                  _currentIndex = index;
                  _isLiked = false;
                  _isBookmarked = false;
                });
              },
              itemBuilder: (context, index) {
                // Each page is its own StatefulWidget that owns the controller
                return _ReelVideoItem(
                  reel: provider.reels[index],
                  isActive: index == _currentIndex,
                );
              },
            ),

          // ── Top overlay (always visible) ─────────────────────────────────
          _buildTopOverlay(),

          // ── Right actions ────────────────────────────────────────────────
          if (!provider.isLoading && provider.reels.isNotEmpty)
            _buildRightActions(provider.reels),

          // ── Bottom info ──────────────────────────────────────────────────
          if (!provider.isLoading && provider.reels.isNotEmpty)
            _buildBottomInfo(provider.reels),
        ],
      ),
    );
  }

  // ── Top Overlay ───────────────────────────────────────────────────────────

  Widget _buildTopOverlay() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.3),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.arrow_back, color: Colors.white, size: 24),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Reels',
                    style: AppTextStyles.heading1.copyWith(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'Property Reel',
                    style: AppTextStyles.caption.copyWith(
                      color: Colors.white.withOpacity(0.7),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.3),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.tune, color: Colors.white, size: 20),
            ),
          ],
        ),
      ),
    );
  }

  // ── Right Actions ─────────────────────────────────────────────────────────

  Widget _buildRightActions(List<ReelModel> reels) {
    final reel = reels[_currentIndex];

    return Positioned(
      right: 12,
      bottom: 180,
      child: Column(
        children: [
          _buildActionButton(
            icon: _isLiked ? Icons.favorite : Icons.favorite_border,
            label: reel.likes.toString(),
            onTap: () => setState(() => _isLiked = !_isLiked),
            isLiked: _isLiked,
          ),
          const SizedBox(height: 20),
          _buildActionButton(
            icon: Icons.comment_outlined,
            label: reel.views.toString(),
            onTap: _showCommentsBottomSheet,
          ),
          const SizedBox(height: 20),
          _buildActionButton(
            icon: Icons.send_outlined,
            label: 'Share',
            onTap: () {},
          ),
          const SizedBox(height: 20),
          _buildActionButton(
            icon: _isBookmarked ? Icons.bookmark : Icons.bookmark_border,
            label: 'Save',
            onTap: () => setState(() => _isBookmarked = !_isBookmarked),
            isLiked: _isBookmarked,
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLiked = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.3),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: isLiked ? Colors.red : Colors.white,
              size: 28,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: AppTextStyles.caption.copyWith(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // ── Bottom Info ───────────────────────────────────────────────────────────

  Widget _buildBottomInfo(List<ReelModel> reels) {
    final reel = reels[_currentIndex];

    return Positioned(
      left: 16,
      right: 80,
      bottom: 80,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            reel.title,
            style: AppTextStyles.heading1.copyWith(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ).animate().fadeIn().slideX(begin: -0.3),

          const SizedBox(height: 8),

          Row(
            children: [
              const Icon(Icons.remove_red_eye_outlined, color: Colors.white, size: 16),
              const SizedBox(width: 4),
              Text(
                '${reel.views} views',
                style: AppTextStyles.body.copyWith(
                  color: Colors.white.withOpacity(0.9),
                  fontSize: 14,
                ),
              ),
            ],
          ).animate().fadeIn(delay: 100.ms).slideX(begin: -0.3),

          const SizedBox(height: 8),

          Text(
            '${reel.likes} likes',
            style: AppTextStyles.heading1.copyWith(
              color: AppColors.primary,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ).animate().fadeIn(delay: 200.ms).slideX(begin: -0.3),

          const SizedBox(height: 16),

          Text(
            reel.description,
            style: AppTextStyles.body.copyWith(
              color: Colors.white.withOpacity(0.8),
              fontSize: 12,
              height: 1.4,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ).animate().fadeIn(delay: 300.ms).slideX(begin: -0.3),
        ],
      ),
    );
  }

  // ── Comments Bottom Sheet ─────────────────────────────────────────────────

  void _showCommentsBottomSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.6,
          decoration: const BoxDecoration(
            color: Color(0xFF1A1A2E),
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.symmetric(vertical: 12),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    const Text(
                      'Comments',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1, color: Colors.white10),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: 5,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CircleAvatar(
                            radius: 20,
                            backgroundImage: NetworkImage(
                              'https://i.pravatar.cc/150?img=${index + 1}',
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'User ${index + 1}',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'This property looks amazing! Would love to schedule a visit.',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.7),
                                    fontSize: 13,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  '2h ago',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.4),
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: Colors.black.withOpacity(0.3)),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'Add a comment...',
                          hintStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(24),
                            borderSide: BorderSide.none,
                          ),
                          filled: true,
                          fillColor: Colors.white.withOpacity(0.1),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 12,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        gradient: AppColors.primaryGradient,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.send, color: Colors.white, size: 20),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _ReelVideoItem — each reel page owns its own VideoPlayerController
//
// Why a separate StatefulWidget instead of managing controllers in the parent?
//   • Flutter's PageView recycles pages; keeping controllers in the parent
//     creates lifecycle mismatches (wrong controller plays, memory leaks).
//   • This widget initialises exactly when it enters the tree and disposes
//     exactly when it leaves — no manual index tracking needed.
// ─────────────────────────────────────────────────────────────────────────────

class _ReelVideoItem extends StatefulWidget {
  const _ReelVideoItem({
    required this.reel,
    required this.isActive,
  });

  final ReelModel reel;

  /// True when this page is the currently visible one in the PageView.
  /// Used to pause videos that have been swiped off-screen.
  final bool isActive;

  @override
  State<_ReelVideoItem> createState() => _ReelVideoItemState();
}

class _ReelVideoItemState extends State<_ReelVideoItem> {
  late VideoPlayerController _controller;
  bool _isInitialized = false;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();
    _initController();
  }

  Future<void> _initController() async {
    try {
      _controller = VideoPlayerController.networkUrl(
        Uri.parse(widget.reel.videoUrl),
      );

      await _controller.initialize();

      // Muted by default
      await _controller.setVolume(0.0);
      // Loop forever
      await _controller.setLooping(true);

      if (mounted) {
        setState(() => _isInitialized = true);
        // Auto-play only if this page is visible
        if (widget.isActive) {
          _controller.play();
        }
      }
    } catch (_) {
      if (mounted) setState(() => _hasError = true);
    }
  }

  @override
  void didUpdateWidget(_ReelVideoItem oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Play / pause when the parent PageView swipes to or away from this page
    if (_isInitialized) {
      widget.isActive ? _controller.play() : _controller.pause();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        // ── Video layer ───────────────────────────────────────────────────
        _buildVideoLayer(),

        // ── "Video" badge ─────────────────────────────────────────────────
        Positioned(
          top: 80,
          left: 16,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              gradient: AppColors.primaryGradient,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.3),
                  blurRadius: 12,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.play_circle_filled_rounded,
                  color: Colors.white,
                  size: 16,
                ),
                const SizedBox(width: 6),
                Text(
                  'Video',
                  style: AppTextStyles.caption.copyWith(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),

        // ── Gradient overlays (same as original) ─────────────────────────
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.3),
                Colors.transparent,
                Colors.black.withOpacity(0.6),
              ],
              stops: const [0.0, 0.3, 1.0],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildVideoLayer() {
    // ── Error fallback ────────────────────────────────────────────────────
    if (_hasError) {
      return Container(
        color: AppColors.primary,
        child: const Center(
          child: Icon(
            Icons.home_work_rounded,
            size: 100,
            color: Colors.white24,
          ),
        ),
      );
    }

    // ── Loading spinner while controller initialises ───────────────────
    if (!_isInitialized) {
      return Container(
        color: Colors.black,
        child: const Center(
          child: CircularProgressIndicator(
            color: Colors.white54,
            strokeWidth: 2,
          ),
        ),
      );
    }

    // ── Actual video, cover-cropped to fill the screen ────────────────
    return SizedBox.expand(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: _controller.value.size.width,
          height: _controller.value.size.height,
          child: VideoPlayer(_controller),
        ),
      ),
    );
  }
}