import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/navigation_provider.dart';
import '../../providers/property_provider.dart';
import '../../models/property_model.dart';
import '../../widgets/search_bar_widget.dart';
import '../../widgets/section_header.dart';
import '../../widgets/property_card_horizontal.dart';
import '../../widgets/bottom_nav_bar.dart';
import '../../widgets/verified_badge.dart';
import '../../widgets/status_tag.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final FocusNode _searchFocusNode = FocusNode();
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _searchFocusNode.requestFocus();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        Provider.of<NavigationProvider>(context, listen: false).setIndex(1);
      }
    });
  }

  @override
  void dispose() {
    _searchFocusNode.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final propertyProvider = Provider.of<PropertyProvider>(context);
    final isQueryNotEmpty = _searchController.text.isNotEmpty;
    final results = propertyProvider.filteredProperties;

    // Suggestions matching query
    final suggestions = propertyProvider.properties
        .where((p) =>
            p.locality.toLowerCase().contains(_searchController.text.toLowerCase()) ||
            p.city.toLowerCase().contains(_searchController.text.toLowerCase()) ||
            p.title.toLowerCase().contains(_searchController.text.toLowerCase()))
        .map((p) => p.locality)
        .toSet()
        .take(5)
        .toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(context),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: SearchBarWidget(
                        hint: 'Search properties, locations...',
                        onTap: null,
                        controller: _searchController,
                        focusNode: _searchFocusNode,
                        onChanged: (val) {
                          propertyProvider.searchProperties(val);
                          setState(() {});
                        },
                        onClear: () {
                          _searchController.clear();
                          propertyProvider.searchProperties('');
                          setState(() {});
                        },
                      ),
                    ),
                    const SizedBox(height: 16),
                    if (!isQueryNotEmpty) ...[
                      _buildFilterChips(),
                      const SizedBox(height: 24),
                      SectionHeader(
                        title: 'Recommended For You',
                        actionLabel: 'See all ›',
                        onActionTap: () {
                          Navigator.pushNamed(context, AppConstants.searchResultsScreen);
                        },
                      ),
                      const SizedBox(height: 12),
                      _buildRecommendedProperties(),
                      const SizedBox(height: 24),
                      SectionHeader(
                        title: 'Recent Searches',
                        actionLabel: 'Clear all',
                        onActionTap: () {},
                      ),
                      _buildRecentSearches(),
                    ] else ...[
                      _buildSuggestions(suggestions, propertyProvider),
                      if (results.isEmpty)
                        _buildEmptyState()
                      else ...[
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          child: Text(
                            'Search Results (${results.length} found)',
                            style: AppTextStyles.heading2.copyWith(fontSize: 18),
                          ),
                        ),
                        const SizedBox(height: 8),
                        ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: results.length,
                          itemBuilder: (context, index) {
                            return _buildPropertyListItem(context, results[index], propertyProvider);
                          },
                        ),
                      ],
                    ],
                    const SizedBox(height: 100),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: const BottomNavBar(
        currentIndex: 1,
      ),
    );
  }

  Widget _buildAppBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
            child: IconButton(
              icon: const Icon(Icons.arrow_back, size: 20),
              onPressed: () {
                if (Navigator.of(context).canPop()) {
                  Navigator.pop(context);
                } else {
                  Provider.of<NavigationProvider>(context, listen: false).setIndex(0);
                  Navigator.popUntil(context, (route) => route.isFirst);
                }
              },
              padding: EdgeInsets.zero,
            ),
          ),
          const SizedBox(width: 16),
          Text(
            'Search',
            style: AppTextStyles.heading2,
          ),
          const Spacer(),
          Container(
            width: 40,
            height: 40,
            decoration: const BoxDecoration(
              color: AppColors.primary,
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.map_outlined,
              color: Colors.white,
              size: 20,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChips() {
    final chips = ['Buy ▾', 'Property Type ▾', 'Price ▾', 'Filters'];
    return SizedBox(
      height: AppConstants.filterChipHeight,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: chips.length,
        itemBuilder: (context, index) {
          final chip = chips[index];
          final isFiltersChip = chip == 'Filters';
          
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Container(
              height: AppConstants.filterChipHeight,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: isFiltersChip
                    ? AppColors.primaryLight
                    : AppColors.cardBackground,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: isFiltersChip
                      ? AppColors.primary
                      : AppColors.textHint.withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: Center(
                child: Text(
                  chip,
                  style: AppTextStyles.chip.copyWith(
                    color: isFiltersChip
                        ? AppColors.primary
                        : AppColors.textPrimary,
                    fontWeight: isFiltersChip ? FontWeight.w600 : FontWeight.w400,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildRecommendedProperties() {
    return Consumer<PropertyProvider>(
      builder: (context, propertyProvider, child) {
        final properties = propertyProvider.properties.take(4).toList();
        return SizedBox(
          height: 320,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: properties.length,
            itemBuilder: (context, index) {
              return PropertyCardHorizontal(
                property: properties[index],
                onTap: () {
                  Navigator.pushNamed(
                    context,
                    AppConstants.propertyDetailScreen,
                    arguments: {'propertyId': properties[index].id},
                  );
                },
                onFavoriteToggle: () {
                  propertyProvider.toggleShortlist(properties[index].id);
                },
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildRecentSearches() {
    final recentSearches = [
      {'location': 'Gachibowli, Hyderabad', 'details': 'Buy • 3 BHK • ₹1 Cr – ₹2 Cr'},
      {'location': 'Jubilee Hills, Hyderabad', 'details': 'Buy • 4 BHK • ₹3 Cr – ₹5 Cr'},
      {'location': 'Madhapur, Hyderabad', 'details': 'Rent • 2 BHK • ₹25K – ₹35K'},
    ];

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: recentSearches.length,
      itemBuilder: (context, index) {
        final search = recentSearches[index];
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: AppColors.primaryLight,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.access_time,
                      color: AppColors.primary,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          search['location'] as String,
                          style: AppTextStyles.body.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          search['details'] as String,
                          style: AppTextStyles.caption,
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, size: 20),
                    onPressed: () {},
                    color: AppColors.textSecondary,
                  ),
                ],
              ),
            ),
            const Divider(height: 0.5),
          ],
        );
      },
    );
  }

  Widget _buildSuggestions(List<String> suggestions, PropertyProvider propertyProvider) {
    if (suggestions.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text(
            'Suggestions',
            style: AppTextStyles.caption.copyWith(fontWeight: FontWeight.bold),
          ),
        ),
        SizedBox(
          height: 36,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: suggestions.length,
            itemBuilder: (context, index) {
              final suggestion = suggestions[index];
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ActionChip(
                  label: Text(suggestion),
                  backgroundColor: AppColors.primaryLight,
                  labelStyle: AppTextStyles.chip.copyWith(
                    color: AppColors.primary,
                    fontWeight: FontWeight.w600,
                  ),
                  onPressed: () {
                    _searchController.text = suggestion;
                    propertyProvider.searchProperties(suggestion);
                    _searchFocusNode.unfocus();
                    setState(() {});
                  },
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 64),
      alignment: Alignment.center,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primaryLight,
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.search_off_rounded,
              color: AppColors.primary,
              size: 48,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'No properties found',
            style: AppTextStyles.heading2.copyWith(fontSize: 20),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Text(
            'We couldn\'t find any properties matching "${_searchController.text}". Check your spelling or try different keywords.',
            style: AppTextStyles.body.copyWith(color: AppColors.textSecondary),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () {
              _searchController.clear();
              Provider.of<PropertyProvider>(context, listen: false).searchProperties('');
              setState(() {});
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            child: const Text('Clear Search'),
          ),
        ],
      ),
    );
  }

  Widget _buildPropertyListItem(BuildContext context, PropertyModel property, PropertyProvider propertyProvider) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(
          context,
          AppConstants.propertyDetailScreen,
          arguments: {'propertyId': property.id},
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          color: AppColors.cardBackground,
          borderRadius: BorderRadius.circular(AppConstants.cardRadius),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(AppConstants.cardRadius),
                    bottomLeft: Radius.circular(AppConstants.cardRadius),
                  ),
                  child: CachedNetworkImage(
                    imageUrl: property.imageUrl,
                    width: AppConstants.propertyListItemImageSize,
                    height: AppConstants.propertyListItemImageSize,
                    fit: BoxFit.cover,
                    placeholder: (context, url) => Container(
                      color: AppColors.textHint.withOpacity(0.1),
                      child: const Center(
                        child: CircularProgressIndicator(),
                      ),
                    ),
                    errorWidget: (context, url, error) => Container(
                      color: AppColors.textHint.withOpacity(0.1),
                      child: const Icon(Icons.error),
                    ),
                  ),
                ),
                if (property.isVerified)
                  const Positioned(
                    top: 8,
                    left: 8,
                    child: VerifiedBadge(),
                  ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: GestureDetector(
                    onTap: () {
                      propertyProvider.toggleShortlist(property.id);
                    },
                    child: Container(
                      width: 32,
                      height: 32,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        property.isShortlisted ? Icons.favorite : Icons.favorite_border,
                        color: property.isShortlisted ? Colors.red : AppColors.textSecondary,
                        size: 18,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 8,
                  left: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.camera_alt,
                          color: Colors.white,
                          size: 10,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${property.photoCount}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            property.title,
                            style: AppTextStyles.body.copyWith(
                              fontWeight: FontWeight.w600,
                              fontSize: 15,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.more_vert, size: 20),
                          onPressed: () {},
                          color: AppColors.textSecondary,
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(
                          Icons.location_on,
                          size: 12,
                          color: AppColors.textSecondary,
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            property.location,
                            style: AppTextStyles.caption,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      property.priceDisplay,
                      style: AppTextStyles.price.copyWith(fontSize: 20),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      property.pricePerSqft,
                      style: AppTextStyles.caption,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        _buildSpecIconListItem(Icons.bed, '${property.beds}'),
                        const SizedBox(width: 12),
                        _buildSpecIconListItem(Icons.bathtub, '${property.baths}'),
                        const SizedBox(width: 12),
                        _buildSpecIconListItem(Icons.square_foot, '${property.sqft}'),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: List<Widget>.from(
                        property.statusTags.take(2).map(
                          (tag) => StatusTag(label: tag.toString()),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSpecIconListItem(IconData icon, String value) {
    return Row(
      children: [
        Icon(
          icon,
          size: 12,
          color: AppColors.textSecondary,
        ),
        const SizedBox(width: 4),
        Text(
          value,
          style: AppTextStyles.caption,
        ),
      ],
    );
  }
}
