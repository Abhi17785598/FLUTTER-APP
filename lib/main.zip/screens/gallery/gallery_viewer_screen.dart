import 'package:flutter/material.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:photo_view/photo_view.dart';

class GalleryViewerScreen extends StatefulWidget {

  final List<String> images;
  final int initialIndex;

  const GalleryViewerScreen({
    super.key,
    required this.images,
    this.initialIndex = 0,
  });

  @override
  State<GalleryViewerScreen> createState() =>
      _GalleryViewerScreenState();
}

class _GalleryViewerScreenState
    extends State<GalleryViewerScreen> {

  late PageController _pageController;

  late int currentIndex;

@override
void initState() {
  super.initState();

  print("GALLERY SCREEN OPENED");

  currentIndex = widget.initialIndex;

  _pageController = PageController(
    initialPage: currentIndex,
  );
}
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.black,

      body: Stack(
        children: [

          PhotoViewGallery.builder(
            pageController: _pageController,

            itemCount: widget.images.length,

            onPageChanged: (index) {
              setState(() {
                currentIndex = index;
              });
            },

            builder: (context, index) {

              return PhotoViewGalleryPageOptions(
                imageProvider:
                    CachedNetworkImageProvider(
                  widget.images[index],
                ),

                minScale:
                    PhotoViewComputedScale.contained,

                maxScale:
                    PhotoViewComputedScale.covered * 3,
              );
            },

            backgroundDecoration:
                const BoxDecoration(
              color: Colors.black,
            ),
          ),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 12,
              ),

              child: Row(
                mainAxisAlignment:
                    MainAxisAlignment.spaceBetween,

                children: [

                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },

                    child: Container(
                      padding:
                          const EdgeInsets.all(10),

                      decoration: BoxDecoration(
                        color:
                            Colors.black.withOpacity(0.5),
                        shape: BoxShape.circle,
                      ),

                      child: const Icon(
                        Icons.arrow_back_ios_new,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                  ),

                  Container(
                    padding:
                        const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 8,
                    ),

                    decoration: BoxDecoration(
                      color:
                          Colors.black.withOpacity(0.5),
                      borderRadius:
                          BorderRadius.circular(20),
                    ),

                    child: Text(
                      '${currentIndex + 1}/${widget.images.length}',

                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}