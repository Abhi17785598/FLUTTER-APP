import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/navigation_provider.dart';
import '../../providers/property_provider.dart';
import '../../providers/filter_provider.dart';
import '../../widgets/bottom_nav_bar.dart';

class FiltersScreen extends StatefulWidget {
  const FiltersScreen({super.key});

  @override
  State<FiltersScreen> createState() => _FiltersScreenState();
}

class _FiltersScreenState extends State<FiltersScreen> {
  String _selectedPropertyType = 'Apartment';
  int? _selectedBedrooms;
  int? _selectedBathrooms;
  RangeValues _priceRange = const RangeValues(20, 500);
  RangeValues _areaRange = const RangeValues(500, 3000);

  final List<Map<String, dynamic>> _propertyTypes = [
    {'name': 'Apartment', 'icon': Icons.apartment, 'color': AppColors.primary},
    {'name': 'Villa', 'icon': Icons.villa, 'color': const Color(0xFF22C55E)},
    {'name': 'Plot', 'icon': Icons.landscape, 'color': const Color(0xFFF97316)},
    {'name': 'Independent House', 'icon': Icons.home, 'color': const Color(0xFF3B82F6)},
    {'name': 'Studio Apartment', 'icon': Icons.bed, 'color': const Color(0xFFEC4899)},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(context),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 16),
                    _buildBuyRentToggle(),
                    const SizedBox(height: 24),
                    _buildPropertyTypeSection(),
                    const SizedBox(height: 24),
                    _buildPriceRangeSection(),
                    const SizedBox(height: 24),
                    _buildBedroomsSection(),
                    const SizedBox(height: 24),
                    _buildBathroomsSection(),
                    const SizedBox(height: 24),
                    _buildAreaRangeSection(),
                    const SizedBox(height: 24),
                    _buildMoreFiltersSection(),
                    const SizedBox(height: 100),
                  ],
                ),
              ),
            ),
            _buildShowResultsButton(context),
          ],
        ),
      ),
      bottomNavigationBar: Consumer<NavigationProvider>(
        builder: (context, navigationProvider, child) {
          return BottomNavBar(
            currentIndex: 1,
            onTap: (index) {
              navigationProvider.setIndex(index);
              if (index == 0) {
                Navigator.popUntil(context, (route) => route.isFirst);
              }
            },
          );
        },
      ),
    );
  }

  Widget _buildAppBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
            child: IconButton(
              icon: const Icon(Icons.arrow_back, size: 20),
              onPressed: () => Navigator.pop(context),
              padding: EdgeInsets.zero,
            ),
          ),
          const SizedBox(width: 16),
          Text(
            'Filters',
            style: AppTextStyles.heading2,
          ),
          const Spacer(),
          TextButton(
            onPressed: () {
              setState(() {
                _selectedPropertyType = 'Apartment';
                _selectedBedrooms = null;
                _selectedBathrooms = null;
                _priceRange = const RangeValues(20, 500);
                _areaRange = const RangeValues(500, 3000);
              });
              Provider.of<PropertyProvider>(context, listen: false).resetFilters();
              Provider.of<FilterProvider>(context, listen: false).resetFilters();
            },
            child: const Text('Reset All ↺'),
          ),
        ],
      ),
    );
  }

  Widget _buildBuyRentToggle() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 50,
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.textHint.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: _buildToggleButton(
              label: 'Buy',
              icon: Icons.shopping_bag,
              isSelected: true,
              onTap: () {},
            ),
          ),
          Expanded(
            child: _buildToggleButton(
              label: 'Rent',
              icon: Icons.home,
              isSelected: false,
              onTap: () {},
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToggleButton({
    required String label,
    required IconData icon,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 18,
              color: isSelected ? Colors.white : AppColors.textSecondary,
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: AppTextStyles.body.copyWith(
                color: isSelected ? Colors.white : AppColors.textSecondary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPropertyTypeSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Property Type',
                style: AppTextStyles.heading3,
              ),
              TextButton(
                onPressed: () {},
                child: const Text('See all'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: AppConstants.propertyTypeChipHeight,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _propertyTypes.length,
              itemBuilder: (context, index) {
                final type = _propertyTypes[index];
                final isSelected = _selectedPropertyType == type['name'];
                return Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectedPropertyType = type['name'] as String;
                      });
                    },
                    child: Container(
                      width: AppConstants.propertyTypeChipWidth,
                      height: AppConstants.propertyTypeChipHeight,
                      decoration: BoxDecoration(
                        color: isSelected ? AppColors.primaryLight : AppColors.cardBackground,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: isSelected ? AppColors.primary : AppColors.textHint.withOpacity(0.3),
                          width: isSelected ? 2 : 1,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            type['icon'] as IconData,
                            color: isSelected ? AppColors.primary : type['color'] as Color,
                            size: 28,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            type['name'] as String,
                            style: AppTextStyles.caption.copyWith(
                              color: isSelected ? AppColors.primary : AppColors.textPrimary,
                              fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                            ),
                            textAlign: TextAlign.center,
                            maxLines: 2,
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPriceRangeSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Price Range',
                style: AppTextStyles.heading3,
              ),
              Row(
                children: [
                  Text(
                    '₹ INR',
                    style: AppTextStyles.body,
                  ),
                  const Icon(Icons.keyboard_arrow_down, size: 20),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          RangeSlider(
            values: _priceRange,
            min: 0,
            max: 1000,
            activeColor: AppColors.primary,
            inactiveColor: AppColors.textHint.withOpacity(0.3),
            onChanged: (values) {
              setState(() {
                _priceRange = values;
              });
            },
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildPriceInput('₹${_priceRange.start.toInt()} L'),
              _buildPriceInput('₹${_priceRange.end.toInt()} Cr+'),
            ],
          ),
          SizedBox(height: 8),
          Center(
            child: Text(
              'Budget: ₹${(_priceRange.start * 100000).toStringAsFixed(0)} – ₹${(_priceRange.end * 10000000).toStringAsFixed(0)}+',
              style: AppTextStyles.caption,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPriceInput(String value) {
    return Container(
      width: 120,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: AppColors.textHint.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Text(
        value,
        style: AppTextStyles.body,
      ),
    );
  }

  Widget _buildBedroomsSection() {
    final bedrooms = ['1 BHK', '2 BHK', '3 BHK', '4 BHK', '4+ BHK'];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Bedrooms',
            style: AppTextStyles.heading3,
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: bedrooms.map((bedroom) {
              final isSelected = _selectedBedrooms == int.parse(bedroom[0]);
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedBedrooms = isSelected ? null : int.parse(bedroom[0]);
                  });
                },
                child: Container(
                  width: AppConstants.selectableChipWidth,
                  height: AppConstants.selectableChipHeight,
                  decoration: BoxDecoration(
                    color: isSelected ? AppColors.primaryLight : AppColors.cardBackground,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: isSelected ? AppColors.primary : AppColors.textHint.withOpacity(0.3),
                      width: isSelected ? 2 : 1,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      bedroom,
                      style: AppTextStyles.body.copyWith(
                        color: isSelected ? AppColors.primary : AppColors.textPrimary,
                        fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildBathroomsSection() {
    final bathrooms = ['1', '2', '3', '4', '4+'];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Bathrooms',
            style: AppTextStyles.heading3,
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: bathrooms.map((bathroom) {
              final isSelected = _selectedBathrooms == int.parse(bathroom == '4+' ? '5' : bathroom);
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedBathrooms = isSelected ? null : int.parse(bathroom == '4+' ? '5' : bathroom);
                  });
                },
                child: Container(
                  width: AppConstants.selectableChipWidth,
                  height: AppConstants.selectableChipHeight,
                  decoration: BoxDecoration(
                    color: isSelected ? AppColors.primaryLight : AppColors.cardBackground,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: isSelected ? AppColors.primary : AppColors.textHint.withOpacity(0.3),
                      width: isSelected ? 2 : 1,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      bathroom,
                      style: AppTextStyles.body.copyWith(
                        color: isSelected ? AppColors.primary : AppColors.textPrimary,
                        fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildAreaRangeSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Area',
            style: AppTextStyles.heading3,
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildAreaInput('${_areaRange.start.toInt()}'),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Text('—'),
              ),
              Expanded(
                child: _buildAreaInput('${_areaRange.end.toInt()}'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAreaInput(String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: AppColors.textHint.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              value,
              style: AppTextStyles.body,
            ),
          ),
          Text(
            'Sq.ft ▾',
            style: AppTextStyles.caption,
          ),
        ],
      ),
    );
  }

  Widget _buildMoreFiltersSection() {
    final filters = [
      {'icon': Icons.chair, 'label': 'Furnishing', 'action': 'Any ›'},
      {'icon': Icons.event_available, 'label': 'Availability', 'action': 'Any ›'},
      {'icon': Icons.pool, 'label': 'Amenities', 'action': 'All ›'},
      {'icon': Icons.history, 'label': 'Age of Property', 'action': 'Any ›'},
      {'icon': Icons.explore, 'label': 'Facing', 'action': 'Any ›'},
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'More Filters',
            style: AppTextStyles.heading3,
          ),
          const SizedBox(height: 12),
          for (final filter in filters)
            Column(
              children: [
                InkWell(
                  onTap: () {},
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Row(
                      children: [
                        Icon(
                          filter['icon'] as IconData,
                          color: AppColors.primary,
                          size: 20,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            filter['label'] as String,
                            style: AppTextStyles.body,
                          ),
                        ),
                        Text(
                          filter['action'] as String,
                          style: AppTextStyles.body.copyWith(
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(height: 0.5),
              ],
            ),
        ],
      ),
    );
  }

  int _getMatchCount() {
    final properties = Provider.of<PropertyProvider>(context, listen: false).properties;
    return properties.where((property) {
      // 1. Property Type
      final typeLower = _selectedPropertyType.toLowerCase();
      bool typeMatches = false;
      if (typeLower == 'apartment') {
        typeMatches = property.title.toLowerCase().contains('apartment') ||
            property.title.toLowerCase().contains('flat') ||
            property.title.toLowerCase().contains('studio');
      } else if (typeLower == 'villa') {
        typeMatches = property.title.toLowerCase().contains('villa');
      } else if (typeLower == 'studio apartment' || typeLower == 'studio') {
        typeMatches = property.title.toLowerCase().contains('studio');
      } else if (typeLower == 'independent house' || typeLower == 'house') {
        typeMatches = property.title.toLowerCase().contains('house') ||
            property.title.toLowerCase().contains('villa');
      } else {
        typeMatches = property.title.toLowerCase().contains(typeLower);
      }

      // 2. Price
      double priceInLakhs = property.price < 20.0 ? property.price * 100 : property.price;
      final priceMatches = priceInLakhs >= _priceRange.start && priceInLakhs <= _priceRange.end;

      // 3. Beds
      final bedsMatches = _selectedBedrooms == null || property.beds == _selectedBedrooms || (_selectedBedrooms! >= 4 && property.beds >= 4);

      // 4. Baths
      final bathsMatches = _selectedBathrooms == null || property.baths == _selectedBathrooms || (_selectedBathrooms! >= 4 && property.baths >= 4);

      // 5. Area
      final areaMatches = property.sqft >= _areaRange.start && property.sqft <= _areaRange.end;

      return typeMatches && priceMatches && bedsMatches && bathsMatches && areaMatches;
    }).length;
  }

  Widget _buildShowResultsButton(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(
          top: BorderSide(
            color: AppColors.textHint,
            width: 0.5,
          ),
        ),
      ),
      child: SizedBox(
        width: double.infinity,
        height: AppConstants.showResultsButtonHeight,
        child: ElevatedButton(
          onPressed: () {
            // Apply to PropertyProvider
            final propProvider = Provider.of<PropertyProvider>(context, listen: false);
            propProvider.applyFilters(
              propertyType: _selectedPropertyType,
              priceRange: _priceRange,
              beds: _selectedBedrooms,
              baths: _selectedBathrooms,
              areaRange: _areaRange,
            );
            
            // Apply to FilterProvider
            final filterProvider = Provider.of<FilterProvider>(context, listen: false);
            filterProvider.setPriceRange(_priceRange);
            filterProvider.setSelectedBedrooms(_selectedBedrooms);
            filterProvider.setSelectedBathrooms(_selectedBathrooms);
            filterProvider.setAreaRange(_areaRange);
            
            // Navigate/Pop
            Navigator.pop(context);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primary,
            foregroundColor: Colors.white,
          ),
          child: Text('Show ${_getMatchCount()} Properties'),
        ),
      ),
    );
  }
}
