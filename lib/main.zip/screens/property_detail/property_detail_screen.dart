import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/property_provider.dart';
import '../../widgets/verified_badge.dart';
import '../../widgets/amenity_icon_tile.dart';
import '../../widgets/nearby_place_row.dart';

// =============================================================================
// PropertyDetailScreen
// Displays full details of a single property including hero image, specs,
// amenities, nearby places, and action buttons for scheduling visits/enquiries.
// =============================================================================
class PropertyDetailScreen extends StatelessWidget {
  final String propertyId;

  const PropertyDetailScreen({
    super.key,
    required this.propertyId,
  });

  @override
  Widget build(BuildContext context) {
    final PropertyProvider propertyProvider =
        Provider.of<PropertyProvider>(context);
    final property = propertyProvider.getPropertyById(propertyId);

    // Guard: show fallback UI if property is not found
    if (property == null) {
      return const Scaffold(
        body: Center(
          child: Text('Property not found'),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          // -----------------------------------------------------------------
          // Hero SliverAppBar with image, back button, actions, and chips
          // -----------------------------------------------------------------
          SliverAppBar(
            expandedHeight: AppConstants.propertyDetailHeroHeight,
            pinned: true,
            // Disable Flutter's automatic back button to avoid double arrows
            automaticallyImplyLeading: false,
            backgroundColor: Colors.transparent,
            // Hide the default AppBar shadow/elevation when collapsed
            elevation: 0,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  // ── Hero image (tappable) ────────────────────────────────
                  _buildHeroImage(context, property),

                  // ── Dark gradient overlay at the bottom ──────────────────
                  _buildGradientOverlay(),

                  // ── Top action row: back + share + favourite ─────────────
                  _buildTopActions(context, property, propertyProvider),

                  // ── Bottom chips: photo count + virtual tour ─────────────
                  Positioned(
                    bottom: 16,
                    left: 16,
                    child: _buildPhotoCountChip(property),
                  ),
                  Positioned(
                    bottom: 16,
                    right: 16,
                    child: _buildVirtualTourChip(context, property),
                  ),
                ],
              ),
            ),
          ),

          // -----------------------------------------------------------------
          // Scrollable content card beneath the hero image
          // -----------------------------------------------------------------
          SliverToBoxAdapter(
            child: Container(
              decoration: const BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 12),

                  // Drag handle indicator
                  Center(
                    child: Container(
                      width: 36,
                      height: 4,
                      decoration: BoxDecoration(
                        color: AppColors.textHint,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Verified badge (conditional)
                        if (property.isVerified)
                          const Padding(
                            padding: EdgeInsets.only(bottom: 12),
                            child: VerifiedBadge(),
                          ),

                        // Title + Price row
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                property.title,
                                style: AppTextStyles.heading2
                                    .copyWith(fontSize: 18),
                              ),
                            ),
                            Text(
                              property.priceDisplay,
                              style: AppTextStyles.price,
                            ),
                          ],
                        ),

                        const SizedBox(height: 8),

                        // Location row
                        Row(
                          children: [
                            const Icon(
                              Icons.location_on,
                              size: 14,
                              color: AppColors.textSecondary,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              property.location,
                              style: AppTextStyles.caption,
                            ),
                          ],
                        ),

                        const SizedBox(height: 4),

                        // Price per sqft
                        Text(
                          property.pricePerSqft,
                          style: AppTextStyles.caption,
                        ),

                        const SizedBox(height: 16),

                        // Property specs (beds, baths, sqft, parking)
                        _buildSpecsRow(property),

                        const SizedBox(height: 16),

                        // About / description section
                        _buildAboutProperty(property),

                        const SizedBox(height: 16),

                        // Amenities horizontal list
                        _buildAmenitiesSection(property),

                        const SizedBox(height: 16),

                        // Nearby places vertical list
                        _buildNearbyPlacesSection(property),

                        // Bottom padding to clear the fixed bottom bar
                        const SizedBox(height: 100),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),

      // Fixed bottom action bar
      bottomNavigationBar:
          _buildBottomBar(context, property, propertyProvider),
    );
  }

  // ===========================================================================
  // HERO IMAGE SECTION
  // ===========================================================================

  /// Builds the tappable hero image with a Hero animation.
  /// Tapping opens a full-screen gallery viewer.
  Widget _buildHeroImage(BuildContext context, dynamic property) {
    return GestureDetector(
      onTap: () => _openGallery(context, property),
      child: Hero(
        // Use property ID as unique Hero tag for smooth page transitions
        tag: 'property_hero_${property.id}',
        child: CachedNetworkImage(
          imageUrl: property.imageUrl,
          fit: BoxFit.cover,
          placeholder: (BuildContext ctx, String url) => Container(
            color: AppColors.textHint.withOpacity(0.1),
          ),
          errorWidget: (BuildContext ctx, String url, Object error) {
            debugPrint(
                '[PropertyDetail] Image load error for ${property.id}: $error');
            return Container(
              color: AppColors.textHint.withOpacity(0.1),
              child: const Center(
                child: Icon(Icons.broken_image,
                    color: AppColors.textSecondary, size: 48),
              ),
            );
          },
        ),
      ),
    );
  }

  /// Semi-transparent gradient that fades from transparent (top) to dark (bottom),
  /// ensuring the chips at the bottom of the hero remain readable.
  Widget _buildGradientOverlay() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.transparent,
            Colors.black.withOpacity(0.3),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // TOP ACTIONS (back · share · favourite)
  // ===========================================================================

  /// Builds the row of action buttons pinned to the top of the hero area.
  /// Contains ONE custom back button (automaticallyImplyLeading is false on the
  /// SliverAppBar, so Flutter will never render a second arrow).
  Widget _buildTopActions(
    BuildContext context,
    dynamic property,
    PropertyProvider propertyProvider,
  ) {
    return Positioned(
      top: MediaQuery.of(context).padding.top + 12,
      left: 16,
      right: 16,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // ── Single custom back button ──────────────────────────────────
          _buildCircleButton(
            backgroundColor: Colors.white,
            child: IconButton(
              icon: const Icon(Icons.arrow_back, size: 20),
              onPressed: () {
                try {
                  if (Navigator.canPop(context)) {
                    Navigator.pop(context);
                  }
                } catch (e) {
                  debugPrint('[PropertyDetail] Back navigation error: $e');
                }
              },
              padding: EdgeInsets.zero,
            ),
            shape: BoxShape.rectangle,
            borderRadius: BorderRadius.circular(8),
          ),

          // ── Share + Favourite ──────────────────────────────────────────
          Row(
            children: [
              // Share button (stub — wire up share_plus or your handler)
              _buildCircleButton(
                backgroundColor: Colors.black.withOpacity(0.5),
                child: const Icon(
                  Icons.share,
                  color: Colors.white,
                  size: 20,
                ),
              ),

              const SizedBox(width: 8),

              // Favourite / shortlist toggle
              GestureDetector(
                onTap: () => propertyProvider.toggleShortlist(property.id),
                child: _buildCircleButton(
                  backgroundColor: Colors.white,
                  child: Icon(
                    property.isShortlisted
                        ? Icons.favorite
                        : Icons.favorite_border,
                    color: property.isShortlisted
                        ? Colors.red
                        : AppColors.textSecondary,
                    size: 20,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Generic 40×40 container used for circular/rounded action buttons.
  Widget _buildCircleButton({
    required Color backgroundColor,
    required Widget child,
    BoxShape shape = BoxShape.circle,
    BorderRadius? borderRadius,
  }) {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: backgroundColor,
        shape: shape,
        borderRadius: shape == BoxShape.rectangle ? borderRadius : null,
      ),
      child: child,
    );
  }

  // ===========================================================================
  // BOTTOM CHIPS (photo count · virtual tour)
  // ===========================================================================

  /// Displays the number of photos available for this property.
  Widget _buildPhotoCountChip(dynamic property) {
    return _buildOverlayChip(
      children: [
        const Icon(Icons.camera_alt, color: Colors.white, size: 14),
        const SizedBox(width: 6),
        Text(
          '${property.photoCount} Photos',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  /// Virtual Tour chip — tappable.
  /// Opens the virtual tour screen if a URL is available; otherwise shows a
  /// SnackBar telling the user the feature is coming soon.
  Widget _buildVirtualTourChip(BuildContext context, dynamic property) {
    return GestureDetector(
      onTap: () => _handleVirtualTour(context, property),
      child: _buildOverlayChip(
        children: const [
          Icon(Icons.play_circle_outline, color: Colors.white, size: 14),
          SizedBox(width: 6),
          Text(
            'Virtual Tour',
            style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  /// Shared semi-transparent pill container used by both bottom chips.
  Widget _buildOverlayChip({required List<Widget> children}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.6),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(children: children),
    );
  }

  // ===========================================================================
  // NAVIGATION HELPERS
  // ===========================================================================

  /// Opens a full-screen gallery viewer for the property images.
  void _openGallery(BuildContext context, dynamic property) {
    debugPrint('[PropertyDetail] Hero image tapped — opening gallery '
        'for property: ${property.id}');
    try {
      Navigator.pushNamed(
        context,
        '/gallery',
        arguments: {
          'propertyId': property.id,
          'imageUrl': property.imageUrl,
          'heroTag': 'property_hero_${property.id}',
        },
      );
    } catch (e) {
      debugPrint('[PropertyDetail] Gallery navigation error: $e');
    }
  }

  /// Handles Virtual Tour button tap.
  /// Navigates to the tour screen when a URL is present; shows a SnackBar otherwise.
  void _handleVirtualTour(BuildContext context, dynamic property) {
    debugPrint('[PropertyDetail] Virtual Tour tapped for property: '
        '${property.id}');

  final String? tourUrl = property.videoUrl;
    if (tourUrl != null && tourUrl.isNotEmpty) {
      try {
        Navigator.pushNamed(
          context,
          '/virtual-tour',
          arguments: {'url': tourUrl, 'title': property.title},
        );
      } catch (e) {
        debugPrint('[PropertyDetail] Virtual Tour navigation error: $e');
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Virtual Tour Coming Soon'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  // ===========================================================================
  // PROPERTY SPECS ROW
  // ===========================================================================

  /// Horizontal row of property spec items separated by vertical dividers.
  Widget _buildSpecsRow(dynamic property) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _buildSpecItem(Icons.bed, '${property.beds}', 'Beds'),
        _buildVerticalDivider(),
        _buildSpecItem(Icons.bathtub, '${property.baths}', 'Baths'),
        _buildVerticalDivider(),
        _buildSpecItem(Icons.square_foot, '${property.sqft}', 'Sq.ft'),
        _buildVerticalDivider(),
        _buildSpecItem(
            Icons.directions_car, '${property.parking}', 'Parking'),
      ],
    );
  }

  /// Single spec item: icon, value, and label stacked vertically.
  Widget _buildSpecItem(IconData icon, String value, String label) {
    return Column(
      children: [
        Icon(icon, size: 24, color: AppColors.textSecondary),
        const SizedBox(height: 4),
        Text(
          value,
          style: AppTextStyles.body.copyWith(
            fontWeight: FontWeight.w600,
            fontSize: 16,
          ),
        ),
        Text(label, style: AppTextStyles.caption),
      ],
    );
  }

  /// Thin vertical divider used between spec items.
  Widget _buildVerticalDivider() {
    return Container(
      width: 1,
      height: 40,
      color: AppColors.textHint.withOpacity(0.3),
    );
  }

  // ===========================================================================
  // ABOUT PROPERTY CARD
  // ===========================================================================

  /// Card that shows the property description with a "Read more" expansion stub.
  Widget _buildAboutProperty(dynamic property) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.textHint.withOpacity(0.3),
          width: 0.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'About Property',
            style: AppTextStyles.body.copyWith(
              fontWeight: FontWeight.w600,
              fontSize: 15,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            property.description as String,
            style: AppTextStyles.caption.copyWith(fontSize: 13),
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 4),
          TextButton(
            onPressed: () {},
            style: TextButton.styleFrom(
              padding: EdgeInsets.zero,
              minimumSize: Size.zero,
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: const Text('Read more ›'),
          ),
        ],
      ),
    );
  }

  // ===========================================================================
  // AMENITIES SECTION
  // ===========================================================================

  /// Section header + horizontal scrollable list of amenity tiles.
  Widget _buildAmenitiesSection(dynamic property) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section header with "View all" button
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Amenities', style: AppTextStyles.heading3),
            TextButton(
              onPressed: () {},
              child: const Text('View all'),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Horizontally scrollable amenity icon tiles
        SizedBox(
          height: 110,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 0),
            itemCount: (property.amenities as List).length,
            itemBuilder: (BuildContext context, int index) {
              final amenity = property.amenities[index];
              return Padding(
                padding: const EdgeInsets.only(right: 16),
                child: AmenityIconTile(
                  icon: _getIconFromString(amenity.icon as String),
                  label: amenity.name as String,
                  color: Color(
                    int.parse(
                      (amenity.color as String).replaceAll('#', '0xFF'),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // ===========================================================================
  // NEARBY PLACES SECTION
  // ===========================================================================

  /// Section header + non-scrolling vertical list of nearby place rows.
  Widget _buildNearbyPlacesSection(dynamic property) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section header with "View all" button
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Nearby Places', style: AppTextStyles.heading3),
            TextButton(
              onPressed: () {},
              child: const Text('View all'),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Non-scrollable list (nested inside CustomScrollView)
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: EdgeInsets.zero,
          itemCount: (property.nearbyPlaces as List).length,
          itemBuilder: (BuildContext context, int index) {
            final place = property.nearbyPlaces[index];
            return NearbyPlaceRow(
              name: place.name as String,
              type: place.type as String,
              distance: place.distance as String,
              duration: place.duration as String,
              icon: _getIconFromString(place.icon as String),
              color: Color(
                int.parse(
                  (place.color as String).replaceAll('#', '0xFF'),
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  // ===========================================================================
  // BOTTOM ACTION BAR
  // ===========================================================================

  /// Fixed bottom bar with "Schedule Visit" and "Enquire Now" buttons.
  Widget _buildBottomBar(
    BuildContext context,
    dynamic property,
    PropertyProvider propertyProvider,
  ) {
    return Container(
      height: 72,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(
          top: BorderSide(color: AppColors.textHint, width: 0.5),
        ),
      ),
      child: Row(
        children: [
          // Schedule Visit — outlined style
          Expanded(
            child: OutlinedButton(
              onPressed: () =>
                  _showScheduleBottomSheet(context, property, propertyProvider),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.primary),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.calendar_today, size: 18),
                  SizedBox(width: 8),
                  Text('Schedule Visit'),
                ],
              ),
            ),
          ),

          const SizedBox(width: 12),

          // Enquire Now — filled style
          Expanded(
            child: ElevatedButton(
              onPressed: () =>
                  _showEnquiryBottomSheet(context, property, propertyProvider),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.phone, size: 18),
                  SizedBox(width: 8),
                  Text('Enquire Now'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ===========================================================================
  // SCHEDULE VISIT BOTTOM SHEET
  // ===========================================================================

  /// Modal bottom sheet that lets the user pick a date and time for a site visit.
  void _showScheduleBottomSheet(
    BuildContext context,
    dynamic property,
    PropertyProvider propertyProvider,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (BuildContext sheetContext) {
        String selectedDate = 'Tomorrow';
        String selectedTime = '10:00 AM';

        return StatefulBuilder(
          builder: (BuildContext ctx, StateSetter setModalState) {
            final List<String> dates = [
              'Tomorrow',
              'May 21, 2026',
              'May 22, 2026',
              'May 23, 2026',
            ];
            final List<String> times = [
              '10:00 AM',
              '12:00 PM',
              '02:00 PM',
              '04:00 PM',
              '06:00 PM',
            ];

            return Container(
              decoration: const BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              padding: EdgeInsets.only(
                left: 16,
                right: 16,
                top: 16,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Drag handle
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: AppColors.textHint,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  Text('Schedule a Visit', style: AppTextStyles.heading2),
                  const SizedBox(height: 4),
                  Text(
                    property.title as String,
                    style:
                        AppTextStyles.body.copyWith(color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 20),

                  // Date selection chips
                  Text(
                    'Select Date',
                    style: AppTextStyles.heading3.copyWith(fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    height: 40,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: dates.length,
                      itemBuilder: (BuildContext _, int index) {
                        final String date = dates[index];
                        final bool isSelected = date == selectedDate;
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(date),
                            selected: isSelected,
                            selectedColor: AppColors.primary,
                            backgroundColor: AppColors.cardBackground,
                            labelStyle: AppTextStyles.chip.copyWith(
                              color: isSelected
                                  ? Colors.white
                                  : AppColors.textSecondary,
                            ),
                            onSelected: (bool selected) {
                              if (selected) {
                                setModalState(() => selectedDate = date);
                              }
                            },
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Time slot selection chips
                  Text(
                    'Select Time Slot',
                    style: AppTextStyles.heading3.copyWith(fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    height: 40,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: times.length,
                      itemBuilder: (BuildContext _, int index) {
                        final String time = times[index];
                        final bool isSelected = time == selectedTime;
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(time),
                            selected: isSelected,
                            selectedColor: AppColors.primary,
                            backgroundColor: AppColors.cardBackground,
                            labelStyle: AppTextStyles.chip.copyWith(
                              color: isSelected
                                  ? Colors.white
                                  : AppColors.textSecondary,
                            ),
                            onSelected: (bool selected) {
                              if (selected) {
                                setModalState(() => selectedTime = time);
                              }
                            },
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 32),

                  // Confirm button
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: () {
                        // Persist the visit through the provider
                        propertyProvider.addVisit({
                          'propertyId': property.id,
                          'title': property.title,
                          'location': property.location,
                          'date': selectedDate,
                          'time': selectedTime,
                          'agentName': 'Rajesh Kumar',
                          'agentPhone': '+91 98765 43210',
                          'status': 'Confirmed',
                          'isUpcoming': true,
                        });
                        Navigator.pop(sheetContext);
                        _showSuccessDialog(context, selectedDate, selectedTime);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'Confirm Schedule',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  /// Success dialog shown after a visit is confirmed.
  void _showSuccessDialog(
      BuildContext context, String date, String time) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 28),
            SizedBox(width: 8),
            Text('Scheduled!'),
          ],
        ),
        content: Text(
            'Your visit is successfully scheduled for $date at $time.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('OK'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              try {
                if (Navigator.canPop(context)) {
                  Navigator.pushNamed(context, '/visits');
                }
              } catch (e) {
                debugPrint(
                    '[PropertyDetail] Navigate to visits error: $e');
              }
            },
            child: const Text('View Visits'),
          ),
        ],
      ),
    );
  }

  // ===========================================================================
  // ENQUIRY BOTTOM SHEET
  // ===========================================================================

  /// Modal bottom sheet with a pre-filled message and a contact-sharing checkbox.
  void _showEnquiryBottomSheet(
    BuildContext context,
    dynamic property,
    PropertyProvider propertyProvider,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (BuildContext sheetContext) {
        final TextEditingController messageController = TextEditingController(
          text:
              'Hi, I am interested in "${property.title}". Please contact me with more details.',
        );
        bool shareContact = true;

        return StatefulBuilder(
          builder: (BuildContext ctx, StateSetter setModalState) {
            return Container(
              decoration: const BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              padding: EdgeInsets.only(
                left: 16,
                right: 16,
                top: 16,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Drag handle
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: AppColors.textHint,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  Text('Enquire About Property',
                      style: AppTextStyles.heading2),
                  const SizedBox(height: 4),
                  Text(
                    property.title as String,
                    style: AppTextStyles.body
                        .copyWith(color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 20),

                  // Message text field
                  TextField(
                    controller: messageController,
                    maxLines: 4,
                    decoration: InputDecoration(
                      hintText: 'Enter your message...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                            color: AppColors.textHint.withOpacity(0.3)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            const BorderSide(color: AppColors.primary),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Contact sharing checkbox
                  Row(
                    children: [
                      Checkbox(
                        value: shareContact,
                        activeColor: AppColors.primary,
                        onChanged: (bool? val) {
                          setModalState(() => shareContact = val ?? true);
                        },
                      ),
                      Expanded(
                        child: Text(
                          'Share my phone number & email with agent',
                          style:
                              AppTextStyles.caption.copyWith(fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Send button
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: () {
                        propertyProvider.incrementEnquiries();
                        Navigator.pop(sheetContext);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                              'Enquiry sent successfully! The agent will contact you shortly.',
                            ),
                            backgroundColor: AppColors.success,
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'Send Enquiry',
                        style:
                            TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // ===========================================================================
  // ICON HELPER
  // ===========================================================================

  /// Maps a string icon identifier (stored in the data model) to a Flutter
  /// [IconData]. Falls back to [Icons.circle] for unrecognised strings.
  IconData _getIconFromString(String iconString) {
    switch (iconString) {
      case 'Icons.apartment':
        return Icons.apartment;
      case 'Icons.pool':
        return Icons.pool;
      case 'Icons.fitness_center':
        return Icons.fitness_center;
      case 'Icons.child_care':
        return Icons.child_care;
      case 'Icons.security':
        return Icons.security;
      case 'Icons.shopping_bag':
        return Icons.shopping_bag;
      case 'Icons.local_hospital':
        return Icons.local_hospital;
      case 'Icons.school':
        return Icons.school;
      case 'Icons.train':
        return Icons.train;
      case 'Icons.business':
        return Icons.business;
      case 'Icons.hotel':
        return Icons.hotel;
      case 'Icons.movie':
        return Icons.movie;
      case 'Icons.directions_car':
        return Icons.directions_car;
      default:
        debugPrint('[PropertyDetail] Unknown icon string: $iconString');
        return Icons.circle;
    }
  }
}