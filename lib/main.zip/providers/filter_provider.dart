import 'package:flutter/material.dart';

class FilterProvider extends ChangeNotifier {
  String _propertyType = 'Buy';
  RangeValues _priceRange = const RangeValues(20, 500);
  int? _selectedBedrooms;
  int? _selectedBathrooms;
  RangeValues _areaRange = const RangeValues(500, 3000);
  String _furnishing = 'Any';
  String _availability = 'Any';
  List<String> _selectedAmenities = [];
  String _ageOfProperty = 'Any';
  String _facing = 'Any';

  String get propertyType => _propertyType;
  RangeValues get priceRange => _priceRange;
  int? get selectedBedrooms => _selectedBedrooms;
  int? get selectedBathrooms => _selectedBathrooms;
  RangeValues get areaRange => _areaRange;
  String get furnishing => _furnishing;
  String get availability => _availability;
  List<String> get selectedAmenities => _selectedAmenities;
  String get ageOfProperty => _ageOfProperty;
  String get facing => _facing;

  void setPropertyType(String type) {
    _propertyType = type;
    notifyListeners();
  }

  void setPriceRange(RangeValues range) {
    _priceRange = range;
    notifyListeners();
  }

  void setSelectedBedrooms(int? bedrooms) {
    _selectedBedrooms = bedrooms;
    notifyListeners();
  }

  void setSelectedBathrooms(int? bathrooms) {
    _selectedBathrooms = bathrooms;
    notifyListeners();
  }

  void setAreaRange(RangeValues range) {
    _areaRange = range;
    notifyListeners();
  }

  void setFurnishing(String value) {
    _furnishing = value;
    notifyListeners();
  }

  void setAvailability(String value) {
    _availability = value;
    notifyListeners();
  }

  void toggleAmenity(String amenity) {
    if (_selectedAmenities.contains(amenity)) {
      _selectedAmenities.remove(amenity);
    } else {
      _selectedAmenities.add(amenity);
    }
    notifyListeners();
  }

  void setAgeOfProperty(String value) {
    _ageOfProperty = value;
    notifyListeners();
  }

  void setFacing(String value) {
    _facing = value;
    notifyListeners();
  }

  void resetFilters() {
    _propertyType = 'Buy';
    _priceRange = const RangeValues(20, 500);
    _selectedBedrooms = null;
    _selectedBathrooms = null;
    _areaRange = const RangeValues(500, 3000);
    _furnishing = 'Any';
    _availability = 'Any';
    _selectedAmenities = [];
    _ageOfProperty = 'Any';
    _facing = 'Any';
    notifyListeners();
  }

  bool hasActiveFilters() {
    return _selectedBedrooms != null ||
        _selectedBathrooms != null ||
        _selectedAmenities.isNotEmpty ||
        _furnishing != 'Any' ||
        _availability != 'Any' ||
        _ageOfProperty != 'Any' ||
        _facing != 'Any';
  }
}
