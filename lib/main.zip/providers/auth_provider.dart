import 'package:flutter/material.dart';
import 'dart:async';
import '../services/auth_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthProvider extends ChangeNotifier {
  bool _isLoggedIn = false;
  String _userName = '';
  String _userEmail = '';
  String? _avatarUrl;
  String? _userRole;
  String? _userType;
  String? _userId;

  final AuthService _authService = AuthService();
  StreamSubscription<AuthState>? _authSub;

  AuthProvider() {
    _authSub = _authService.onAuthStateChange.listen((state) {

      debugPrint('===================');
debugPrint('AUTH EVENT: ${state.event}');
debugPrint('HAS SESSION: ${state.session != null}');
debugPrint('EMAIL: ${state.session?.user.email}');
debugPrint('===================');

      if (state.session != null) {
        _isLoggedIn = true;

        final currentUser = _authService.currentUser;

        if (currentUser != null) {
          _userName =
              currentUser.userMetadata?['display_name'] ?? '';

          _userEmail =
              currentUser.email ?? '';

          _fetchUserProfile();
        }
      } else {
        _isLoggedIn = false;
        _userName = '';
        _userEmail = '';
        _avatarUrl = null;
        _userRole = null;
        _userType = null;
      }

      notifyListeners();
    });
  }

  Future<void> _fetchUserProfile() async {
    final currentUser = _authService.currentUser;

    if (currentUser == null) return;

    try {
      final profile =
          await _authService.getUserProfile(currentUser.id);

      if (profile != null) {
        _userName =
            profile['display_name'] ?? _userName;

        _userEmail =
            profile['email'] ?? _userEmail;

        _avatarUrl =
            profile['avatar_url'];

       _userRole = profile['user_role'];

_userType = profile['user_type'];
_userId = currentUser.id;



debugPrint("================================");
debugPrint("PROFILE FETCHED");
debugPrint("ROLE = $_userRole");
debugPrint("TYPE = $_userType");
debugPrint("================================");

notifyListeners();
      }
    } catch (e) {
      debugPrint('Error fetching user profile: $e');
    }
  }

  @override
  void dispose() {
    _authSub?.cancel();
    super.dispose();
  }

  bool get isLoggedIn => _isLoggedIn;
  String get userName => _userName;
  String get userEmail => _userEmail;
  String? get avatarUrl => _avatarUrl;
  String? get userRole => _userRole;
  String? get userType => _userType;
  String? get userId => _userId;

  Future<String?> login(
    String email,
    String password,
  ) async {
    if (email.trim().isEmpty || password.isEmpty) {
      return 'Please fill in all fields';
    }

    try {
      await _authService.login(
        email.trim(),
        password,
      );

      return null;
    } on AuthException catch (e) {
      return e.message;
    } catch (e) {
      return e.toString();
    }
  }

  Future<String?> signUp(
    String name,
    String email,
    String password,
    String confirmPassword, {
    String role = 'buyer',
    String type = 'individual',
  }) async {
    if (name.trim().isEmpty ||
        email.trim().isEmpty ||
        password.isEmpty) {
      return 'Please fill in all fields';
    }

    if (password != confirmPassword) {
      return 'Passwords do not match';
    }

    if (password.length < 6) {
      return 'Password must be at least 6 characters';
    }

    try {
      if (role == 'buyer') {
  type = 'individual';
}
      await _authService.signUp(
        email.trim(),
        password,
        name.trim(),
        role: role,
        type: type,
      );

      return null;
    } on AuthException catch (e) {
      return e.message;
    } catch (e) {
      return e.toString();
    }
  }

  Future<void> updateProfileData({
  required String name,
  required String role,
  required String type,
}) async {
  await _authService.updateProfileData(
    name: name,
    role: role,
    type: type,
  );

  await _fetchUserProfile();
}

  Future<void> logout() async {
    await _authService.logout();

    _isLoggedIn = false;
    _userName = '';
    _userEmail = '';
    _avatarUrl = null;
    _userRole = null;
    _userType = null;
    _userId = null;

    notifyListeners();
  }

  void updateProfile(
    String name,
    String email,
  ) {
    _userName = name.trim();
    _userEmail = email.trim();

    notifyListeners();
  }
}