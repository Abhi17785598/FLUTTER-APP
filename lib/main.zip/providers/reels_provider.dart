import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/reel_model.dart';
import '../services/reels_service.dart';

class ReelsProvider with ChangeNotifier {
  bool _hasCompletedOnboarding = false;

  String? _selectedCity;
  String? _selectedBudget;
  String? _selectedPropertyType;

  final ReelsService _reelsService = ReelsService();

  List<ReelModel> _reels = [];
  bool _isLoading = false;

  List<ReelModel> get reels => _reels;
  bool get isLoading => _isLoading;

  bool get hasCompletedOnboarding => _hasCompletedOnboarding;
  String? get selectedCity => _selectedCity;
  String? get selectedBudget => _selectedBudget;
  String? get selectedPropertyType => _selectedPropertyType;

  ReelsProvider() {
    _loadPreferences();
    loadReels();
  }

  Future<void> loadReels() async {
    try {
      _isLoading = true;
      notifyListeners();

      final data = await _reelsService.getReels();

      _reels = data
          .map((e) => ReelModel.fromSupabase(e))
          .toList();

      debugPrint('Loaded reels: ${_reels.length}');
    } catch (e) {
      debugPrint('Reels error: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();

    _hasCompletedOnboarding =
        prefs.getBool('hasCompletedReelsOnboarding') ?? false;

    _selectedCity = prefs.getString('reelsCity');
    _selectedBudget = prefs.getString('reelsBudget');
    _selectedPropertyType = prefs.getString('reelsPropertyType');

    notifyListeners();
  }

  Future<void> completeOnboarding({
    required String city,
    required String budget,
    required String propertyType,
  }) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setBool('hasCompletedReelsOnboarding', true);
    await prefs.setString('reelsCity', city);
    await prefs.setString('reelsBudget', budget);
    await prefs.setString('reelsPropertyType', propertyType);

    _hasCompletedOnboarding = true;
    _selectedCity = city;
    _selectedBudget = budget;
    _selectedPropertyType = propertyType;

    notifyListeners();
  }
}