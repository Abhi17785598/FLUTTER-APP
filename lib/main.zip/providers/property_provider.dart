import 'package:flutter/material.dart';
import '../models/property_model.dart';
import '../services/property_service.dart';

class PropertyProvider extends ChangeNotifier {
  List<PropertyModel> _properties = [];
  List<PropertyModel> _filteredProperties = [];
  String _searchQuery = '';

  List<PropertyModel> get properties => _properties;
  List<PropertyModel> get filteredProperties => _filteredProperties;
  String get searchQuery => _searchQuery;

 PropertyProvider() {
  loadProperties();
}

final PropertyService _propertyService = PropertyService();

Future<void> loadProperties() async {
  try {
    final data = await _propertyService.getProperties();

    print("================================");
    print("RAW PROPERTY COUNT: ${data.length}");

    if (data.isNotEmpty) {
      print("FIRST PROPERTY:");
      print(data.first);
    }

    _properties = data
        .map((item) => PropertyModel.fromSupabase(item))
        .toList();

    print("MAPPED PROPERTY COUNT: ${_properties.length}");

    _filteredProperties = List.from(_properties);

    notifyListeners();
  } catch (e, stack) {
    print("================================");
    print("PROPERTY ERROR:");
    print(e);
    print(stack);
    print("================================");
  }
}

  void searchProperties(String query) {
    _searchQuery = query.toLowerCase();
    if (_searchQuery.isEmpty) {
      _filteredProperties = List.from(_properties);
    } else {
      _filteredProperties = _properties.where((property) {
        return property.title.toLowerCase().contains(_searchQuery) ||
            property.locality.toLowerCase().contains(_searchQuery) ||
            property.city.toLowerCase().contains(_searchQuery) ||
            property.builderName.toLowerCase().contains(_searchQuery) ||
            property.statusTags.any((tag) => tag.toLowerCase().contains(_searchQuery));
      }).toList();
    }
    notifyListeners();
  }

  void applyFilters({
    required String propertyType,
    required RangeValues priceRange,
    required int? beds,
    required int? baths,
    required RangeValues areaRange,
  }) {
    _filteredProperties = _properties.where((property) {
      // 1. Property Type
      final typeLower = propertyType.toLowerCase();
      bool typeMatches = false;
      if (typeLower == 'apartment') {
        typeMatches = property.title.toLowerCase().contains('apartment') ||
            property.title.toLowerCase().contains('flat') ||
            property.title.toLowerCase().contains('studio');
      } else if (typeLower == 'villa') {
        typeMatches = property.title.toLowerCase().contains('villa');
      } else if (typeLower == 'studio apartment' || typeLower == 'studio') {
        typeMatches = property.title.toLowerCase().contains('studio');
      } else if (typeLower == 'independent house' || typeLower == 'house') {
        typeMatches = property.title.toLowerCase().contains('house') ||
            property.title.toLowerCase().contains('villa');
      } else {
        typeMatches = property.title.toLowerCase().contains(typeLower);
      }

      // 2. Price
      double priceInLakhs = property.price < 20.0 ? property.price * 100 : property.price;
      final priceMatches = priceInLakhs >= priceRange.start && priceInLakhs <= priceRange.end;

      // 3. Beds
      final bedsMatches = beds == null || property.beds == beds || (beds >= 4 && property.beds >= 4);

      // 4. Baths
      final bathsMatches = baths == null || property.baths == baths || (baths >= 4 && property.baths >= 4);

      // 5. Area
      final areaMatches = property.sqft >= areaRange.start && property.sqft <= areaRange.end;

      return typeMatches && priceMatches && bedsMatches && bathsMatches && areaMatches;
    }).toList();
    notifyListeners();
  }

  void resetFilters() {
    _searchQuery = '';
    _filteredProperties = List.from(_properties);
    notifyListeners();
  }

  void toggleShortlist(String propertyId) {
    final index = _properties.indexWhere((p) => p.id == propertyId);
    if (index != -1) {
      _properties[index] = _properties[index].copyWith(
        isShortlisted: !_properties[index].isShortlisted,
      );
      
      final filteredIndex = _filteredProperties.indexWhere((p) => p.id == propertyId);
      if (filteredIndex != -1) {
        _filteredProperties[filteredIndex] = _filteredProperties[filteredIndex].copyWith(
          isShortlisted: !_filteredProperties[filteredIndex].isShortlisted,
        );
      }
      notifyListeners();
    }
  }

  List<PropertyModel> getShortlistedProperties() {
    return _properties.where((p) => p.isShortlisted).toList();
  }

  List<PropertyModel> getFeaturedProperties() {
    return _properties.where((p) => p.isFeatured).toList();
  }

  PropertyModel? getPropertyById(String id) {
    try {
      return _properties.firstWhere((p) => p.id == id);
    } catch (e) {
      return null;
    }
  }

  // Visit Management
  final List<Map<String, dynamic>> _visits = [
    {
      'propertyId': '1',
      'title': 'Luxury 3BHK Apartment',
      'location': 'Koramangala, Bangalore',
      'date': 'Tomorrow',
      'time': '10:00 AM',
      'agentName': 'Rajesh Kumar',
      'agentPhone': '+91 98765 43210',
      'status': 'Confirmed',
      'isUpcoming': true,
    },
    {
      'propertyId': '2',
      'title': 'Modern Villa',
      'location': 'Whitefield, Bangalore',
      'date': 'May 22, 2026',
      'time': '2:00 PM',
      'agentName': 'Priya Sharma',
      'agentPhone': '+91 98765 43211',
      'status': 'Pending',
      'isUpcoming': true,
    },
    {
      'propertyId': '3',
      'title': '2BHK Apartment',
      'location': 'Indiranagar, Bangalore',
      'date': 'May 15, 2026',
      'time': '11:00 AM',
      'agentName': 'Amit Patel',
      'rating': 4,
      'isUpcoming': false,
      'status': 'Completed',
    },
    {
      'propertyId': '4',
      'title': 'Studio Apartment',
      'location': 'HSR Layout, Bangalore',
      'date': 'May 10, 2026',
      'time': '3:00 PM',
      'agentName': 'Sneha Reddy',
      'rating': 5,
      'isUpcoming': false,
      'status': 'Completed',
    },
  ];

  List<Map<String, dynamic>> get visits => _visits;

  void addVisit(Map<String, dynamic> visit) {
    _visits.insert(0, visit);
    notifyListeners();
  }

  void cancelVisit(String propertyId) {
    final index = _visits.indexWhere((v) => v['propertyId'] == propertyId && v['isUpcoming'] == true && v['status'] != 'Cancelled');
    if (index != -1) {
      _visits[index] = {
        ..._visits[index],
        'status': 'Cancelled',
      };
      notifyListeners();
    }
  }

  int _enquiriesCount = 3;
  int get enquiriesCount => _enquiriesCount;

  void incrementEnquiries() {
    _enquiriesCount++;
    notifyListeners();
  }
}
