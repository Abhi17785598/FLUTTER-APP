class ReelModel {
  final String id;
  final String title;
  final String description;
  final String videoUrl;
  final int views;
  final int likes;

  ReelModel({
    required this.id,
    required this.title,
    required this.description,
    required this.videoUrl,
    required this.views,
    required this.likes,
  });

  factory ReelModel.fromSupabase(Map<String, dynamic> json) {
    return ReelModel(
      id: json['id'].toString(),
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      videoUrl: json['video_url'] ?? '',
      views: json['views'] ?? 0,
      likes: json['likes'] ?? 0,
    );
  }
}