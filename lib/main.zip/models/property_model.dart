import 'amenity_model.dart';

class PropertyModel {
  final String id;
  final String title;
  final String locality;
  final String city;
  final double price;
  final String priceDisplay;
  final String pricePerSqft;
  final int beds;
  final int baths;
  final int sqft;
  final int parking;
  final bool isVerified;
  final bool isFeatured;
  final bool isShortlisted;
  final int photoCount;
  final List<String> statusTags;
  final List<AmenityModel> amenities;
  final List<NearbyPlaceModel> nearbyPlaces;
  final String description;
  final String imageUrl;
  final String builderName;
  final String? propertyType;
  final String? possessionStatus;
  final double? rating;
  final int? reviewCount;
  final bool isTrending;
  final String? floorPlanUrl;
  final String? videoUrl;

  PropertyModel({
    required this.id,
    required this.title,
    required this.locality,
    required this.city,
    required this.price,
    required this.priceDisplay,
    required this.pricePerSqft,
    required this.beds,
    required this.baths,
    required this.sqft,
    required this.parking,
    required this.isVerified,
    required this.isFeatured,
    required this.isShortlisted,
    required this.photoCount,
    required this.statusTags,
    required this.amenities,
    required this.nearbyPlaces,
    required this.description,
    required this.imageUrl,
    required this.builderName,
    this.propertyType,
    this.possessionStatus,
    this.rating,
    this.reviewCount,
    this.isTrending = false,
    this.floorPlanUrl,
    this.videoUrl,
  });

  factory PropertyModel.fromJson(Map<String, dynamic> json) {
    return PropertyModel(
      id: json['id'] as String,
      title: json['title'] as String,
      locality: json['locality'] as String,
      city: json['city'] as String,
      price: (json['price'] as num).toDouble(),
      priceDisplay: json['priceDisplay'] as String,
      pricePerSqft: json['pricePerSqft'] as String,
      beds: json['beds'] as int,
      baths: json['baths'] as int,
      sqft: json['sqft'] as int,
      parking: json['parking'] as int,
      isVerified: json['isVerified'] as bool,
      isFeatured: json['isFeatured'] as bool,
      isShortlisted: json['isShortlisted'] as bool,
      photoCount: json['photoCount'] as int,
      statusTags: (json['statusTags'] as List<dynamic>).cast<String>(),
      amenities: (json['amenities'] as List<dynamic>)
          .map((e) => AmenityModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      nearbyPlaces: (json['nearbyPlaces'] as List<dynamic>)
          .map((e) => NearbyPlaceModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      description: json['description'] as String,
      imageUrl: json['imageUrl'] as String,
      builderName: json['builderName'] as String,
      propertyType: json['propertyType'] as String?,
      possessionStatus: json['possessionStatus'] as String?,
      rating: (json['rating'] as num?)?.toDouble(),
      reviewCount: json['reviewCount'] as int?,
      isTrending: json['isTrending'] as bool? ?? false,
      floorPlanUrl: json['floorPlanUrl'] as String?,
      videoUrl: json['videoUrl'] as String?,
    );
  }

  factory PropertyModel.fromSupabase(Map<String, dynamic> json) {
  // Extract residential data if available
  final residential = json['properties_residential'] as Map<String, dynamic>?;
  final commercial = json['properties_commercial'] as Map<String, dynamic>?;

  // FIX: Read media from properties.media_urls text[] array.
  // The 'property_media' table does not exist in this database.
  // Images are stored as a text[] column directly on the properties row.
  final mediaUrls = List<String>.from(json['media_urls'] ?? [])
      .where((url) => url.isNotEmpty)
      .toList();

  // Extract beds, baths, parking from residential or commercial data
  int beds = 0;
  int baths = 0;
  int parking = 0;

  if (residential != null) {
    beds    = residential['bedrooms']       as int? ?? 0;
    baths   = residential['bathrooms']      as int? ?? 0;
    // FIX: DB column is 'parking_spaces', not 'parking'
    parking = residential['parking_spaces'] as int? ?? 0;
  } else if (commercial != null) {
    beds    = commercial['washrooms']       as int? ?? 0;
    baths   = commercial['washrooms']       as int? ?? 0;
    // FIX: DB column is 'parking_spaces', not 'parking'
    parking = commercial['parking_spaces']  as int? ?? 0;
  }

  // Extract metadata
  final metadata = json['metadata'] as Map<String, dynamic>? ?? {};

  // FIX: 'is_featured' column does not exist yet on the properties table.
  // Use views >= 50 as a proxy for featured status until the column is added
  // via the migration in the forensic report. Once the column exists, the
  // null-coalesce below will read the real DB value automatically.
 final isFeatured =
    (json['views'] as int? ?? 0) >= 1;

  // Trending: properties with at least 20 views this week
  final isTrending = (json['views'] as int? ?? 0) >= 20;

  return PropertyModel(
    id:              json['id']?.toString() ?? '',
    title:           json['title'] ?? '',
    locality:        json['location'] ?? '',
    city:            metadata['city']?.toString() ?? json['city']?.toString() ?? '',
    price:           double.tryParse(json['price']?.toString() ?? '0') ?? 0,
    priceDisplay:    formatIndianPrice(json['price']),
    pricePerSqft:    metadata['pricePerSqFt']?.toString() ?? '',
    beds:            beds,
    baths:           baths,
    sqft:            int.tryParse(json['area']?.toString() ?? '0') ?? 0,
    parking:         parking,
    isVerified:      json['is_verified'] as bool? ?? true,
    isFeatured:      isFeatured,
    isShortlisted:   false,
    photoCount:      mediaUrls.length,
    statusTags:      List<String>.from(json['hashtags'] ?? []),
    amenities:       [],
    nearbyPlaces:    [],
    description:     json['description'] ?? '',
    imageUrl:        mediaUrls.isNotEmpty ? mediaUrls.first : '',
    builderName:     json['builder_name']?.toString() ?? json['category']?.toString() ?? '',
    propertyType:    json['property_type']?.toString(),
    possessionStatus: metadata['propertyCondition']?.toString() ??
                      json['possession_status']?.toString(),
    isTrending:      isTrending,
  );
}

  static String formatIndianPrice(dynamic value) {
  final price = double.tryParse(value.toString()) ?? 0;

  if (price >= 10000000) {
    return '₹${(price / 10000000).toStringAsFixed(1)} Cr';
  }

  if (price >= 100000) {
    return '₹${(price / 100000).toStringAsFixed(1)} L';
  }

  return '₹${price.toInt()}';
}

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'locality': locality,
      'city': city,
      'price': price,
      'priceDisplay': priceDisplay,
      'pricePerSqft': pricePerSqft,
      'beds': beds,
      'baths': baths,
      'sqft': sqft,
      'parking': parking,
      'isVerified': isVerified,
      'isFeatured': isFeatured,
      'isShortlisted': isShortlisted,
      'photoCount': photoCount,
      'statusTags': statusTags,
      'amenities': amenities.map((e) => e.toJson()).toList(),
      'nearbyPlaces': nearbyPlaces.map((e) => e.toJson()).toList(),
      'description': description,
      'imageUrl': imageUrl,
      'builderName': builderName,
      'propertyType': propertyType,
      'possessionStatus': possessionStatus,
      'rating': rating,
      'reviewCount': reviewCount,
      'isTrending': isTrending,
      'floorPlanUrl': floorPlanUrl,
      'videoUrl': videoUrl,
    };
  }

  PropertyModel copyWith({
    String? id,
    String? title,
    String? locality,
    String? city,
    double? price,
    String? priceDisplay,
    String? pricePerSqft,
    int? beds,
    int? baths,
    int? sqft,
    int? parking,
    bool? isVerified,
    bool? isFeatured,
    bool? isShortlisted,
    int? photoCount,
    List<String>? statusTags,
    List<AmenityModel>? amenities,
    List<NearbyPlaceModel>? nearbyPlaces,
    String? description,
    String? imageUrl,
    String? builderName,
    String? propertyType,
    String? possessionStatus,
    double? rating,
    int? reviewCount,
    bool? isTrending,
    String? floorPlanUrl,
    String? videoUrl,
  }) {
    return PropertyModel(
      id: id ?? this.id,
      title: title ?? this.title,
      locality: locality ?? this.locality,
      city: city ?? this.city,
      price: price ?? this.price,
      priceDisplay: priceDisplay ?? this.priceDisplay,
      pricePerSqft: pricePerSqft ?? this.pricePerSqft,
      beds: beds ?? this.beds,
      baths: baths ?? this.baths,
      sqft: sqft ?? this.sqft,
      parking: parking ?? this.parking,
      isVerified: isVerified ?? this.isVerified,
      isFeatured: isFeatured ?? this.isFeatured,
      isShortlisted: isShortlisted ?? this.isShortlisted,
      photoCount: photoCount ?? this.photoCount,
      statusTags: statusTags ?? this.statusTags,
      amenities: amenities ?? this.amenities,
      nearbyPlaces: nearbyPlaces ?? this.nearbyPlaces,
      description: description ?? this.description,
      imageUrl: imageUrl ?? this.imageUrl,
      builderName: builderName ?? this.builderName,
      propertyType: propertyType ?? this.propertyType,
      possessionStatus: possessionStatus ?? this.possessionStatus,
      rating: rating ?? this.rating,
      reviewCount: reviewCount ?? this.reviewCount,
      isTrending: isTrending ?? this.isTrending,
      floorPlanUrl: floorPlanUrl ?? this.floorPlanUrl,
      videoUrl: videoUrl ?? this.videoUrl,
    );
  }

  String get location => '$locality, $city';
}
