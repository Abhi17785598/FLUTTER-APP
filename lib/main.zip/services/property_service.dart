import 'package:supabase_flutter/supabase_flutter.dart';

class PropertyService {
  final _supabase = Supabase.instance.client;

  Future<List<Map<String, dynamic>>> getProperties() async {
    final data = await _supabase
        .from('properties')
      .select('*,properties_residential(*),properties_commercial(*),properties_land(*)')
        .eq('status', 'active')
        .order('created_at', ascending: false);

    return List<Map<String, dynamic>>.from(data);
  }
}