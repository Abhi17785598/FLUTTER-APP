import 'package:supabase_flutter/supabase_flutter.dart';

class ReelsService {
  final _supabase = Supabase.instance.client;

  Future<List<Map<String, dynamic>>> getReels() async {
    final data = await _supabase
        .from('influencer_videos')
        .select('*')
        .eq('status', 'active')
        .eq('approval_status', 'approved')
        .order('created_at', ascending: false);

    return List<Map<String, dynamic>>.from(data);
  }
}