import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import '../../app_navigator.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/validation/validators.dart';
import '../../core/widgets/scale_tap.dart';
import '../../providers/auth_provider.dart';
import '../../voice_agent/widgets/voice_agent_panel.dart';

/// The real, official Google "G" mark (Google's own multi-colour logo, as
/// used on every standard "Sign in with Google" button) — inlined as raw SVG
/// so it renders pixel-accurately via the app's existing `flutter_svg`
/// dependency, with no new package and no new asset file. Replaces the
/// earlier hand-painted 4-arc approximation, which read as an approximation
/// rather than the real logo.
const String _googleLogoSvg = '''
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
  <path fill="#4285F4" d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z"/>
  <path fill="#34A853" d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z"/>
  <path fill="#FBBC05" d="M11.69 28.18C11.25 26.86 11 25.45 11 24s.25-2.86.69-4.18v-5.7H4.34C2.85 17.09 2 20.45 2 24s.85 6.91 2.34 9.88l7.35-5.7z"/>
  <path fill="#EA4335" d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7c1.73-5.2 6.58-9.07 12.31-9.07z"/>
</svg>
''';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> with TickerProviderStateMixin {
  late TabController _tabController;
  late AnimationController _headerController;
  late Animation<double> _logoAnimation;
  late Animation<double> _text1Animation;
  late Animation<double> _text2Animation;

  // Login controllers
  final _loginEmailCtrl = TextEditingController();
  final _loginPasswordCtrl = TextEditingController();
  bool _loginPasswordVisible = false;

  // Sign Up — email only, portal parity. No name/password/role/type here:
  // Supabase's own `signInWithOtp(shouldCreateUser: true)` both creates the
  // account (if new) and signs in (if existing) with a magic link, and Full
  // Name + User Type are collected afterwards, once the link is confirmed
  // and a real session exists — see AccountTypeScreen.
  final _signUpEmailCtrl = TextEditingController();
  bool _signUpEmailSent = false;
  String? _signUpSentTo;

  // Phone controllers
  final _phoneNameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();

  bool _isLoading = false;
  bool _googleOAuthStarting = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _headerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _logoAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _headerController,
        curve: const Interval(0.0, 0.5, curve: Curves.elasticOut),
      ),
    );

    _text1Animation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _headerController,
        curve: const Interval(0.3, 0.7, curve: Curves.easeOut),
      ),
    );

    _text2Animation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _headerController,
        curve: const Interval(0.5, 0.9, curve: Curves.easeOut),
      ),
    );

    _headerController.forward();

    // A blocked-account sign-out (AuthProvider.handleBlockedAccount) lands
    // here — surface its message through the same snackbar every other
    // auth failure already uses, rather than a new screen.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final blockedMessage = AuthProvider.consumeBlockedMessage();
      if (blockedMessage != null && mounted) {
        _showSnackBar(blockedMessage, isError: true);
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _headerController.dispose();
    _loginEmailCtrl.dispose();
    _loginPasswordCtrl.dispose();
    _signUpEmailCtrl.dispose();
    _phoneNameCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  // ─── Validation ───────────────────────────────────────────

  Future<void> _handleForgotPassword() async {
    final email = _loginEmailCtrl.text.trim();
    if (email.isEmpty) {
      _showSnackBar(
        'Enter your email address above, then tap Forgot password.',
        isError: true,
      );
      return;
    }
    setState(() => _isLoading = true);
    final error = await context.read<AuthProvider>().resetPassword(email);
    setState(() => _isLoading = false);
    if (!mounted) return;
    if (error != null) {
      _showSnackBar('Could not send reset email: $error', isError: true);
    } else {
      _showSnackBar(
        'Password reset email sent. Check your inbox.',
        isError: false,
      );
    }
  }

  String? _validateLogin() {
    // Email or username only — phone sign-in lives on the Phone tab and is
    // never password-based (see AuthService.loginWithIdentifier).
    final idErr = Validators.required(_loginEmailCtrl.text);
    if (idErr != null) return idErr;
    if (_loginPasswordCtrl.text.isEmpty) return 'Password is required.';
    if (_loginPasswordCtrl.text.length < 6) {
      return 'Password must be at least 6 characters.';
    }
    return null;
  }

  String? _validatePhoneForm() {
    return Validators.required(_phoneCtrl.text) ??
        Validators.phone(_phoneCtrl.text);
  }

  String? _validateSignUpEmail() {
    return Validators.required(_signUpEmailCtrl.text) ??
        Validators.email(_signUpEmailCtrl.text);
  }

  // ─── Handlers ─────────────────────────────────────────────

  Future<void> _handleGoogleSignIn() async {
    // Stops double taps and simultaneous authentication actions.
    if (_isLoading || _googleOAuthStarting) return;

    setState(() => _googleOAuthStarting = true);
    debugPrint('[GOOGLE_OAUTH] Google sign-in requested');

    final error = await context.read<AuthProvider>().signInWithGoogle();

    if (!mounted) return;

    setState(() => _googleOAuthStarting = false);

    if (error != null) {
      _showSnackBar(error, isError: true);
    }
  }

  Future<void> _handleLogin() async {
    final validationError = _validateLogin();
    if (validationError != null) {
      _showSnackBar(validationError, isError: true);
      return;
    }
    setState(() => _isLoading = true);
    final error = await context.read<AuthProvider>().login(
      _loginEmailCtrl.text.trim(),
      _loginPasswordCtrl.text,
    );
    if (!mounted) return;
    setState(() => _isLoading = false);
    if (error != null) {
      _showSnackBar(error, isError: true);
    }
    // On success, AuthProvider's own auth-stream listener resolves the
    // destination and navigates — this screen does not decide where to go.
  }

  Future<void> _handleSendOtp() async {
    final validationError = _validatePhoneForm();
    if (validationError != null) {
      _showSnackBar(validationError, isError: true);
      return;
    }
    setState(() => _isLoading = true);
    final error = await context.read<AuthProvider>().sendOtp(
      _phoneCtrl.text.trim(),
    );
    setState(() => _isLoading = false);
    if (error != null) {
      _showSnackBar(error, isError: true);
      return;
    }
    if (!mounted) return;
    final name = _phoneNameCtrl.text.trim();
    await Navigator.pushNamed(
      context,
      '/auth-otp',
      arguments: {
        'phone': Validators.toE164(_phoneCtrl.text.trim()),
        if (name.isNotEmpty) 'name': name,
      },
    );
  }

  Future<void> _handleSignUp() async {
    final validationError = _validateSignUpEmail();
    if (validationError != null) {
      _showSnackBar(validationError, isError: true);
      return;
    }
    final email = _signUpEmailCtrl.text.trim();
    setState(() => _isLoading = true);
    final error = await context.read<AuthProvider>().signUpWithEmail(email);
    setState(() => _isLoading = false);
    if (error != null) {
      _showSnackBar(error, isError: true);
      return;
    }
    setState(() {
      _signUpEmailSent = true;
      _signUpSentTo = email;
    });
  }

  Future<void> _handleResendSignUpEmail() async {
    final email = _signUpSentTo;
    if (email == null) return;
    setState(() => _isLoading = true);
    final error = await context.read<AuthProvider>().signUpWithEmail(email);
    setState(() => _isLoading = false);
    if (!mounted) return;
    if (error != null) {
      _showSnackBar(error, isError: true);
    } else {
      _showSnackBar('Confirmation email resent.', isError: false);
    }
  }

  /// Opens the same assistant panel `FloatingAiOrb._openPanel` does — that
  /// widget's own `_openPanel` is private, so this mirrors its two-line body
  /// (same `appNavigatorKey` overlay context, same `VoiceAgentPanel`, same
  /// `VoiceAgentProvider` underneath) rather than reaching into its private
  /// state. This is an inline, auth-route-local trigger for the identical
  /// assistant functionality — not a second assistant.
  ///
  /// `floating_ai_orb.dart` and `app.dart` are both untouched: this screen
  /// has no way to also suppress the *floating* orb's global presentation
  /// without editing one of those two files, which is out of scope here
  /// (global overlay infrastructure) — see the redesign report for that
  /// reported gap.
  void _openHelpPanel() {
    final overlayContext = appNavigatorKey.currentState?.overlay?.context;
    if (overlayContext == null) return;
    showModalBottomSheet(
      context: overlayContext,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const VoiceAgentPanel(),
    );
  }

  void _showSnackBar(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: isError
            ? Colors.red.shade700
            : AppColors.verifiedBadge,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  // ─── Root Build ───────────────────────────────────────────

  /// Same premium house photo already used elsewhere in this app (the
  /// second slide of the Home hero carousel, `HeroBannerSection`) — reused
  /// verbatim rather than a new, unrelated image.
  ///
  /// This is the one piece of hero artwork this redesign could not source
  /// exactly: the reference shows a specific "modern white property"
  /// photograph, but no such asset (or any local hero image at all) exists
  /// in this checkout — every hero photo across the app, this one included,
  /// is already a remote Unsplash URL. Reusing this exact existing URL is a
  /// reported fallback, not a claim that it is the same photograph as the
  /// reference.
  static const String _backgroundImageUrl =
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=900&q=80';

  @override
  Widget build(BuildContext context) {
    // Bottom safe-area inset (home indicator / gesture bar), folded into the
    // card's own bottom padding below rather than left to `SafeArea` — the
    // card must reach the literal bottom edge of the screen with no bare
    // strip of background left showing under it, on every device, so it
    // owns that inset itself instead of a wrapping `SafeArea` reserving it
    // as dead space above the card.
    final bottomInset = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            _buildHero(),
            // The white sheet carrying the tab bar and the active form.
            // `Expanded` pins it to fill every bit of remaining space down
            // to the true bottom edge of the screen — on a tall device
            // that's more empty card padding; on a short one (or with the
            // keyboard open) its own `SingleChildScrollView` below takes
            // over instead, so the card is never left short of the bottom
            // edge, and nothing here is ever clipped rather than scrolled.
            Expanded(
              child: ClipRRect(
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(28),
                  topRight: Radius.circular(28),
                ),
                child: ColoredBox(
                  color: Colors.white,
                  child: SingleChildScrollView(
                    keyboardDismissBehavior:
                        ScrollViewKeyboardDismissBehavior.onDrag,
                    // A bit more than just `bottomInset` at the tail: the
                    // globally-mounted `FloatingAiOrb` (app.dart) still
                    // floats over this screen too — see the "Need help?"
                    // doc comment below — so the last interactive element
                    // gets real clearance from it rather than sitting flush
                    // against the bottom edge.
                    padding: EdgeInsets.fromLTRB(24, 22, 24, 40 + bottomInset),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildTabBar(),
                        const SizedBox(height: 22),
                        // Use AnimatedBuilder to rebuild tab content on tab switch
                        AnimatedBuilder(
                          animation: _tabController,
                          builder: (context, _) {
                            switch (_tabController.index) {
                              case 0:
                                return _buildLoginForm();
                              case 1:
                                return _buildSignUpForm();
                              default:
                                return _buildPhoneForm();
                            }
                          },
                        ),
                        const SizedBox(height: 20),
                        _buildHelpFooter(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Hero ─────────────────────────────────────────────────
  //
  // Full-width architectural photo (the building sits toward the right via
  // `alignment: Alignment.centerRight`), a left-to-right white wash so the
  // wordmark/headline stay legible over it without a separate bordered
  // "photo card", and a height that scales with the viewport instead of a
  // fixed pixel value — so a short screen doesn't lose all its room to a
  // hero that refuses to shrink.

  Widget _buildHero() {
    final double screenHeight = MediaQuery.of(context).size.height;
    final double heroHeight = (screenHeight * 0.36).clamp(230.0, 340.0);
    final double maxTextWidth = MediaQuery.of(context).size.width * 0.72;

    return AnimatedBuilder(
      animation: _headerController,
      builder: (context, child) {
        // A `minHeight`, not a fixed height: at default text scale this is
        // exactly `heroHeight`, but enlarged text scaling (or a very long
        // system font substitution) can make the wordmark/headline/subtitle
        // column taller than that — a fixed `SizedBox` would rather overflow
        // than yield, so this lets the hero grow to fit instead. The two
        // background layers are `Positioned.fill`, so they always cover
        // whatever height the Stack actually resolves to either way.
        return SizedBox(
          width: double.infinity,
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: heroHeight),
            child: Stack(
              children: [
                Positioned.fill(
                  child: CachedNetworkImage(
                    imageUrl: _backgroundImageUrl,
                    fit: BoxFit.cover,
                    alignment: Alignment.centerRight,
                    placeholder: (context, url) =>
                        Container(color: AppColors.primaryLight),
                    errorWidget: (context, url, error) =>
                        Container(color: AppColors.primaryLight),
                  ),
                ),
                // Strongest immediately behind the text on the left, fading
                // out well before the right edge so the building itself
                // stays visible there — not the previous pass's separate
                // bordered photo card.
                const Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [Color(0xF2F8F8FC), Color(0x14F8F8FC)],
                        stops: [0.0, 0.85],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: maxTextWidth),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // The wordmark. No dedicated "propcid" logo asset
                        // (vector or image) is reachable from this
                        // environment to prepare faithfully — see the
                        // redesign report for exactly why — so this
                        // remains styled text, same as every other place
                        // "PropCID" appears in this app (e.g. the splash
                        // screen). Recognisable as the same wordmark, but
                        // not a reproduction of bespoke letter shapes.
                        FadeTransition(
                          opacity: _logoAnimation,
                          child: Text(
                            'propcid',
                            style: AppTextStyles.heading1.copyWith(
                              fontSize: 30,
                              fontWeight: FontWeight.w800,
                              color: AppColors.primary,
                              letterSpacing: -0.5,
                            ),
                          ),
                        ),
                        const SizedBox(height: 18),
                        FadeTransition(
                          opacity: _text1Animation,
                          child: Text(
                            'Your next home',
                            style: AppTextStyles.heading1.copyWith(
                              fontSize: 25,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                              height: 1.2,
                            ),
                          ),
                        ),
                        FadeTransition(
                          opacity: _text2Animation,
                          child: Text(
                            'starts here.',
                            style: AppTextStyles.heading1.copyWith(
                              fontSize: 25,
                              fontWeight: FontWeight.w800,
                              color: AppColors.primary,
                              height: 1.2,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        FadeTransition(
                          opacity: _text2Animation,
                          child: Text(
                            'Discover. Explore. Own.',
                            style: AppTextStyles.body.copyWith(
                              fontSize: 14,
                              color: AppColors.textSecondary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ─── Tab Bar ──────────────────────────────────────────────
  //
  // A compact custom segmented control, matching the reference's "Sign In /
  // Sign Up / Phone" pill row — replacing the previous full-height `TabBar`
  // with its heavy card/shadow treatment. Still driven by the same
  // `_tabController` at the same three indices; nothing about which form
  // shows for which index has changed, only how the control itself is
  // painted (`TabBar`/`Tab`/`_IconTab` are no longer used here at all).

  Widget _buildTabBar() {
    return AnimatedBuilder(
      animation: _tabController,
      builder: (context, _) {
        return Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.primaryLight, width: 1.2),
          ),
          child: Row(
            children: [
              _buildTabSegment(
                index: 0,
                icon: Icons.person_outline,
                label: 'Sign In',
              ),
              _buildTabSegment(index: 1, icon: Icons.add, label: 'Sign Up'),
              _buildTabSegment(
                index: 2,
                icon: Icons.phone_outlined,
                label: 'Phone',
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTabSegment({
    required int index,
    required IconData icon,
    required String label,
  }) {
    final bool selected = _tabController.index == index;
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => setState(() => _tabController.animateTo(index)),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: selected ? AppColors.primary : Colors.transparent,
            borderRadius: BorderRadius.circular(13),
            boxShadow: selected ? AppColors.primaryActionShadow : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 15,
                color: selected ? Colors.white : AppColors.textSecondary,
              ),
              const SizedBox(width: 5),
              Flexible(
                child: Text(
                  label,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                    color: selected ? Colors.white : AppColors.textSecondary,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Inline "Need help?" — shared chrome under every tab, matching the
  /// reference's persistent footer rather than being Sign-In-specific.
  /// Terms/Privacy links are deliberately not reproduced alongside it: no
  /// genuine destination for either exists yet (checked — every other
  /// "Terms"/"Privacy" mention in this app is plain checkbox-label text,
  /// never an actual route or URL), and a non-functional link was
  /// explicitly ruled out.
  Widget _buildHelpFooter() {
    return Center(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _openHelpPanel,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.support_agent_rounded,
              size: 16,
              color: AppColors.primary,
            ),
            const SizedBox(width: 6),
            Text(
              'Need help?',
              style: AppTextStyles.body.copyWith(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: AppColors.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Login Form ───────────────────────────────────────────

  Widget _buildLoginForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Welcome back',
          style: AppTextStyles.heading1.copyWith(fontSize: 21),
        ),
        const SizedBox(height: 5),
        Text(
          'Sign in to continue your property journey.',
          style: AppTextStyles.body.copyWith(
            fontSize: 13.5,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 20),
        _buildTextField(
          controller: _loginEmailCtrl,
          label: 'Email or username',
          hint: 'Enter your email or username',
          icon: Icons.email_outlined,
          keyboardType: TextInputType.text,
        ),
        const SizedBox(height: 14),
        _buildTextField(
          controller: _loginPasswordCtrl,
          label: 'Password',
          hint: 'Enter your password',
          icon: Icons.lock_outline,
          isPassword: true,
          passwordVisible: _loginPasswordVisible,
          onTogglePassword: () =>
              setState(() => _loginPasswordVisible = !_loginPasswordVisible),
        ),
        const SizedBox(height: 4),
        Align(
          alignment: Alignment.centerRight,
          child: TextButton(
            onPressed: _isLoading ? null : _handleForgotPassword,
            child: const Text(
              'Forgot password?',
              style: TextStyle(color: AppColors.primary, fontSize: 13),
            ),
          ),
        ),
        const SizedBox(height: 8),
        _buildPrimaryButton(
          label: 'Sign In',
          onPressed: _isLoading ? null : _handleLogin,
        ),
        const SizedBox(height: 20),
        _buildDivider(),
        const SizedBox(height: 16),
        _buildGoogleButton(),
        const SizedBox(height: 20),
        // Switches the existing TabController to the Sign Up tab in place —
        // no new route, same as tapping the "Sign Up" segment above. A
        // `Wrap`, not a `Row`: at 320px width or with enlarged text scaling
        // the two pieces need to be able to fall onto separate lines rather
        // than force an unbounded-width overflow.
        Wrap(
          alignment: WrapAlignment.center,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            Text(
              'New to PropCid? ',
              style: AppTextStyles.body.copyWith(
                fontSize: 13,
                color: AppColors.textSecondary,
              ),
            ),
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => setState(() => _tabController.animateTo(1)),
              child: Text(
                'Sign up',
                style: AppTextStyles.body.copyWith(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppColors.primary,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ─── Sign Up Form ─────────────────────────────────────────
  // Portal parity: email only. Full Name + User Type are collected after
  // the magic link is confirmed and a session exists (AccountTypeScreen) —
  // there is no role/type choice here, and never a Buyer/Seller one.

  Widget _buildSignUpForm() {
    if (_signUpEmailSent) {
      return _buildSignUpConfirmationState();
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildTextField(
          controller: _signUpEmailCtrl,
          label: 'Email',
          hint: 'you@example.com',
          icon: Icons.email_outlined,
          keyboardType: TextInputType.emailAddress,
        ),
        const SizedBox(height: 22),
        _buildPrimaryButton(
          label: 'Create Account',
          onPressed: _isLoading ? null : _handleSignUp,
        ),
        const SizedBox(height: 20),
        _buildDivider(),
        const SizedBox(height: 16),
        _buildGoogleButton(),
      ],
    );
  }

  Widget _buildSignUpConfirmationState() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Icon(
          Icons.mark_email_read_outlined,
          size: 48,
          color: AppColors.primary,
        ),
        const SizedBox(height: 16),
        const Text(
          'Check your email',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'We sent a confirmation link to ${_signUpSentTo ?? ''}. Tap it on this device to continue.',
          style: const TextStyle(fontSize: 14, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 20),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton(
            onPressed: _isLoading ? null : _handleResendSignUpEmail,
            child: Text(
              _isLoading ? 'Sending…' : 'Resend email',
              style: const TextStyle(color: AppColors.primary, fontSize: 13),
            ),
          ),
        ),
      ],
    );
  }

  // ─── Phone Form ───────────────────────────────────────────
  // One unified entry point regardless of sign-in vs sign-up: the backend
  // creates the account if the phone is new, or logs the user in if it
  // already exists — there is no separate "phone sign up" step.

  Widget _buildPhoneForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildTextField(
          controller: _phoneNameCtrl,
          label: 'Name (new accounts only)',
          hint: 'Enter your full name',
          icon: Icons.person_outline,
        ),
        const SizedBox(height: 14),
        _buildTextField(
          controller: _phoneCtrl,
          label: 'Phone number',
          hint: '10-digit mobile number',
          icon: Icons.phone_outlined,
          keyboardType: TextInputType.phone,
        ),
        const SizedBox(height: 4),
        const Text(
          'We will text you a 6-digit code.',
          style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
        ),
        const SizedBox(height: 18),
        _buildPrimaryButton(
          label: 'Send OTP',
          onPressed: _isLoading ? null : _handleSendOtp,
        ),
      ],
    );
  }

  // ─── Shared Widgets ───────────────────────────────────────

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    bool isPassword = false,
    bool passwordVisible = false,
    VoidCallback? onTogglePassword,
    TextInputType keyboardType = TextInputType.text,
  }) {
    // Matches the reference: a persistent label above the field, and a
    // separate (usually more specific) hint painted inside it once it's
    // empty. Previously `hint` was accepted but never used — `label` was
    // painted as the visible hintText instead, so the two arguments always
    // showed the same string no matter what `hint` actually said. Fixed
    // here in presentation only: same controller, same keyboardType, same
    // obscureText/onTogglePassword wiring, same validation (nothing here
    // participates in it either before or after).
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: AppTextStyles.caption.copyWith(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          obscureText: isPassword && !passwordVisible,
          keyboardType: keyboardType,
          style: const TextStyle(fontSize: 14, color: AppColors.textPrimary),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(color: AppColors.textHint, fontSize: 14),
            prefixIcon: Icon(icon, color: AppColors.textSecondary, size: 20),
            suffixIcon: isPassword
                ? IconButton(
                    onPressed: onTogglePassword,
                    icon: Icon(
                      passwordVisible
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      color: AppColors.textSecondary,
                      size: 20,
                    ),
                  )
                : null,
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(
                color: AppColors.primaryLight,
                width: 1.2,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(
                color: AppColors.primaryLight,
                width: 1.2,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(
                color: AppColors.primary,
                width: 1.6,
              ),
            ),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 14,
            ),
          ),
        ),
      ],
    );
  }

  /// Delegates to [_AuthPrimaryButton] rather than the shared `PremiumButton`
  /// — same call signature as before (label/onPressed/icon), so every call
  /// site above is untouched, but `PremiumButton` itself (used across the
  /// rest of the app) is never modified. The reference's CTA reads "Sign
  /// In →" — label, then a trailing arrow — which `PremiumButton` cannot
  /// produce: it always renders its `icon` *before* the label. Building a
  /// small auth-local widget for the trailing-icon layout was the
  /// alternative explicitly allowed over changing `PremiumButton` globally.
  Widget _buildPrimaryButton({
    required String label,
    required VoidCallback? onPressed,
    IconData? icon = Icons.arrow_forward_rounded,
  }) {
    return _AuthPrimaryButton(
      label: label,
      onPressed: onPressed,
      isLoading: _isLoading,
      icon: icon,
    );
  }

  Widget _buildDivider() {
    return Row(
      children: [
        const Expanded(child: Divider(color: AppColors.hairline)),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Text(
            'or continue with',
            style: AppTextStyles.caption.copyWith(fontSize: 12),
          ),
        ),
        const Expanded(child: Divider(color: AppColors.hairline)),
      ],
    );
  }

  Widget _buildGoogleButton() {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: OutlinedButton(
        onPressed: (_isLoading || _googleOAuthStarting)
            ? null
            : _handleGoogleSignIn,
        style: OutlinedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          side: const BorderSide(color: AppColors.primaryLight, width: 1.2),
          backgroundColor: Colors.white,
          disabledBackgroundColor: AppColors.surfaceMuted,
        ),
        // Explicit centered Row rather than `.icon()`'s own layout, so the
        // icon+label group is guaranteed centered as a unit — matching the
        // target rather than relying on the constructor's default padding.
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            _googleOAuthStarting
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : SvgPicture.string(_googleLogoSvg, width: 20, height: 20),
            const SizedBox(width: 10),
            Flexible(
              child: Text(
                _googleOAuthStarting
                    ? 'Opening Google…'
                    : 'Continue with Google',
                overflow: TextOverflow.ellipsis,
                style: AppTextStyles.body.copyWith(
                  fontSize: 14,
                  // Stronger than the previous w500, matching the target.
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Auth-local primary CTA. Reproduces `PremiumButton`'s gradient/glow/
/// loading treatment (that file is untouched and still used everywhere
/// else), but with the label truly centered in the button regardless of
/// the icon — `PremiumButton` centers the icon-and-label *group* as one
/// unit, which visually off-centers the label whenever an icon is present.
/// The target centers "Sign In" on its own and pins the arrow near the
/// button's right inset instead.
class _AuthPrimaryButton extends StatelessWidget {
  const _AuthPrimaryButton({
    required this.label,
    required this.onPressed,
    required this.isLoading,
    this.icon,
  });

  final String label;
  final VoidCallback? onPressed;
  final bool isLoading;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return ScaleTap(
      onTap: isLoading ? null : onPressed,
      child: Container(
        width: double.infinity,
        height: 52,
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient,
          borderRadius: BorderRadius.circular(14),
          boxShadow: AppColors.primaryGlow,
        ),
        child: isLoading
            ? const Center(
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                ),
              )
            : Stack(
                alignment: Alignment.center,
                children: [
                  // Centered independently of the arrow, not as a group
                  // with it — this is the whole point of the `Stack`
                  // instead of `PremiumButton`'s single centered `Row`.
                  Center(child: Text(label, style: AppTextStyles.button)),
                  if (icon != null)
                    Positioned(
                      right: 18,
                      child: Icon(icon, size: 18, color: Colors.white),
                    ),
                ],
              ),
      ),
    );
  }
}
