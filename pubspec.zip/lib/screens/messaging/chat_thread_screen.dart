import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/widgets/empty_state_view.dart';
import '../../providers/auth_provider.dart';
import '../../providers/chat_thread_provider.dart';
import 'widgets/chat_avatar.dart';
import 'widgets/chat_bubble.dart';
import 'widgets/message_composer.dart';

/// A single conversation, 1:1 or channel (blueprint §16.7 and §16.8).
///
/// One screen serves both. §16.8 suggests a shared base widget rather than
/// duplicating the thread; parameterising the single screen by
/// [ChatThreadKind] achieves that with no second class to keep in sync — the
/// only differences are which table is read (owned by [ChatThreadProvider])
/// and whether bubbles are attributed to a sender.
class ChatThreadScreen extends StatelessWidget {
  final ChatThreadKind kind;
  final String threadId;
  final String title;

  /// Secondary header line — a member count for channels. Nothing is shown for
  /// 1:1 threads: the prototype's "Online" label has no reliable presence
  /// source (see the note on ConversationTile).
  final String? subtitle;

  final String? avatarUrl;
  final String initials;

  const ChatThreadScreen({
    super.key,
    required this.kind,
    required this.threadId,
    required this.title,
    required this.initials,
    this.subtitle,
    this.avatarUrl,
  });

  @override
  Widget build(BuildContext context) {
    final userId = context.read<AuthProvider>().userId;

    if (userId == null) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return ChangeNotifierProvider(
      create: (_) => ChatThreadProvider(
        kind: kind,
        threadId: threadId,
        userId: userId,
      )..load(),
      child: _ChatThreadView(
        title: title,
        subtitle: subtitle,
        avatarUrl: avatarUrl,
        initials: initials,
        currentUserId: userId,
      ),
    );
  }
}

class _ChatThreadView extends StatelessWidget {
  final String title;
  final String? subtitle;
  final String? avatarUrl;
  final String initials;
  final String currentUserId;

  const _ChatThreadView({
    required this.title,
    required this.subtitle,
    required this.avatarUrl,
    required this.initials,
    required this.currentUserId,
  });

  @override
  Widget build(BuildContext context) {
    final thread = context.watch<ChatThreadProvider>();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          _Header(
            title: title,
            subtitle: subtitle,
            avatarUrl: avatarUrl,
            initials: initials,
          ),
          Expanded(child: _buildBody(context, thread)),
          MessageComposer(
            sending: thread.sending,
            onSend: thread.send,
          ),
        ],
      ),
    );
  }

  Widget _buildBody(BuildContext context, ChatThreadProvider thread) {
    if (thread.loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (thread.failed && thread.messages.isEmpty) {
      return Center(
        child: EmptyStateView(
          icon: Icons.cloud_off_rounded,
          title: "Couldn't load messages",
          message: 'Check your connection and try again.',
          actionLabel: 'Retry',
          onAction: thread.refresh,
        ),
      );
    }

    if (thread.messages.isEmpty) {
      return const Center(
        child: EmptyStateView(
          icon: Icons.chat_bubble_outline,
          title: 'No messages yet',
          message: 'Say hello to start the conversation.',
        ),
      );
    }

    // `reverse: true` anchors the list to the newest message and keeps it
    // pinned when the keyboard opens, so no scroll controller is needed.
    final ordered = thread.messages.reversed.toList();

    return ListView.builder(
      reverse: true,
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      itemCount: ordered.length,
      itemBuilder: (context, index) {
        final message = ordered[index];
        final isMine = message.senderId == currentUserId;

        return ChatBubble(
          message: message,
          isMine: isMine,
          senderName: thread.isChannel && !isMine
              ? thread.senderFor(message.senderId)?.displayName
              : null,
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  final String title;
  final String? subtitle;
  final String? avatarUrl;
  final String initials;

  const _Header({
    required this.title,
    required this.subtitle,
    required this.avatarUrl,
    required this.initials,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.cardBackground,
        border: Border(bottom: BorderSide(color: Color(0xFFEDEDF2))),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 20, 12),
          child: Row(
            children: [
              Semantics(
                label: 'Back',
                button: true,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    width: 34,
                    height: 34,
                    decoration: const BoxDecoration(
                      color: AppColors.background,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.arrow_back,
                      size: 17,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              ChatAvatar(
                avatarUrl: avatarUrl,
                initials: initials,
                size: 38,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTextStyles.body.copyWith(
                        fontSize: 14.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (subtitle != null && subtitle!.isNotEmpty) ...[
                      const SizedBox(height: 1),
                      Text(
                        subtitle!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTextStyles.caption.copyWith(
                          fontSize: 11,
                          color: AppColors.textHint,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
