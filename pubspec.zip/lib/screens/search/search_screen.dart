import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../providers/navigation_provider.dart';
import '../../providers/filter_provider.dart';
import '../../providers/recent_searches_provider.dart';
import '../../models/global_search_suggestion.dart';
import '../../models/smart_query_result.dart';
import '../../services/property_service.dart';
import '../../services/ai_search_service.dart';
import '../../services/voice_search_service.dart';
import '../../widgets/search_bar_widget.dart';
import '../../widgets/bottom_nav_bar.dart';

// ── Prototype dimensions without an existing token ───────────────────────────
// Phase 1 deliberately does NOT add to AppConstants; these live here until a
// second consumer needs them.

/// The Search Entry bar's corner radius. Its height (54) is already
/// `AppConstants.searchBarHeight`; 18 has no token.
const double _kEntryBarRadius = 18;

/// Gap between the bar's search icon, field and mic badge.
const double _kEntryBarGap = 10;

/// A recent-search row: 46 dp tall, 14 dp side padding, 10 dp icon gap.
const double _kRecentRowHeight = 46;
const double _kRecentRowPadding = 14;

/// One suggestion group in the autocomplete list.
///
/// `global_search` emits exactly four types — city, property, project and
/// builder. Only the two listed below are groupable here, because the other two
/// have nowhere to go: this app has no project-detail screen and no public
/// profile screen for another user (that is the not-yet-started Phase 12 of the
/// master blueprint). `_fetchSuggestions` drops them for the same reason, so a
/// tap can never dead-end. Note the portal's own TypeScript declares a
/// `locality` type as well, but the deployed RPC never returns one.
class _SuggestionGroup {
  final String type;
  final String label;
  final IconData icon;

  const _SuggestionGroup({
    required this.type,
    required this.label,
    required this.icon,
  });
}

/// Fixed order, mirroring the website's own city-before-property grouping.
const List<_SuggestionGroup> _kSuggestionGroups = [
  _SuggestionGroup(
    type: 'city',
    label: 'CITIES',
    icon: Icons.location_city,
  ),
  _SuggestionGroup(
    type: 'property',
    label: 'PROPERTIES',
    icon: Icons.home_work_outlined,
  ),
];

/// The gradient mic badge: 38 dp square at a 13 dp radius.
const double _kMicBadgeSize = 38;
const double _kMicBadgeRadius = 13;

/// Circular app-bar buttons. 36 dp is the size the redesign uses for the
/// back/action circles on its other screens (Messages, Manage Dashboard).
const double _kAppBarButtonSize = 36;

/// A "Search by property type" pill.
///
/// Apartment and Villa are both `category: residential` and are distinguished
/// only by subtype, so a pill has to carry the pair — `category` alone cannot
/// represent them. The subtype match terms are the same ones
/// [FiltersScreen] already uses, verified against the live
/// `residential_subtype` column rather than guessed from a label.
class _PropertyTypeOption {
  final String label;
  final String category;
  final String? subtype;

  const _PropertyTypeOption({
    required this.label,
    required this.category,
    this.subtype,
  });
}

const List<_PropertyTypeOption> _kPropertyTypes = [
  _PropertyTypeOption(
      label: 'Apartment', category: 'residential', subtype: 'Flat'),
  _PropertyTypeOption(
      label: 'Villa', category: 'residential', subtype: 'Villa'),
  _PropertyTypeOption(label: 'Plot', category: 'land'),
  _PropertyTypeOption(label: 'Commercial', category: 'commercial'),
];

class SearchScreen extends StatefulWidget {
  // Set when navigated here from a mic icon elsewhere in the app (e.g. the
  // Home screen's search-bar preview) so voice listening starts immediately
  // instead of requiring a second tap once this screen loads.
  final bool autoStartVoice;

  const SearchScreen({super.key, this.autoStartVoice = false});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final FocusNode _searchFocusNode = FocusNode();
  final TextEditingController _searchController = TextEditingController();
  final PropertyService _propertyService = PropertyService();
  final AiSearchService _aiSearchService = AiSearchService();
  final VoiceSearchService _voiceSearchService = VoiceSearchService();

  Timer? _debounce;
  List<GlobalSearchSuggestion> _suggestions = [];
  bool _isLoadingSuggestions = false;

  // AI parsing of a submitted query. Runs for EVERY free-text search — there is
  // no longer an opt-in "Smart Search" toggle, matching both the website (which
  // always parses) and the redesign (which advertises AI search with no toggle).
  bool _isParsingSmartQuery = false;

  // Voice Search — on-device speech-to-text feeding the same search box.
  bool _isListening = false;

  @override
  void initState() {
    super.initState();
    // If we're about to auto-start voice listening, don't also pop the
    // keyboard up — the user tapped a mic icon to speak, not to type.
    if (!widget.autoStartVoice) {
      _searchFocusNode.requestFocus();
    }
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      Provider.of<NavigationProvider>(context, listen: false).setIndex(1);
      if (widget.autoStartVoice) {
        _toggleVoiceSearch();
      }
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchFocusNode.dispose();
    _searchController.dispose();
    if (_isListening) {
      _voiceSearchService.cancelListening();
    }
    super.dispose();
  }

  void _onQueryChanged(String value) {
    _debounce?.cancel();
    if (value.trim().length < 3) {
      setState(() => _suggestions = []);
      return;
    }
    _debounce = Timer(
      const Duration(milliseconds: 300),
      () => _fetchSuggestions(value),
    );
  }

  Future<void> _fetchSuggestions(String term) async {
    setState(() => _isLoadingSuggestions = true);
    try {
      final results = await _propertyService.globalSearch(term);
      if (!mounted) return;
      setState(() {
        // project/builder suggestion types point at routes that don't exist
        // in this app yet — dropped rather than left to dead-end.
        _suggestions =
            results.where((s) => s.type == 'city' || s.type == 'property').toList();
        _isLoadingSuggestions = false;
      });
    } catch (e) {
      debugPrint('[SearchScreen] suggestions failed: $e');
      if (!mounted) return;
      setState(() => _isLoadingSuggestions = false);
    }
  }

  /// Submits the current query. The text is first parsed by AI
  /// (AiSearchService, calling the website's existing openai-proxy edge
  /// function) into structured filters — city/bhk/category/listingType/budget —
  /// which are applied through the SAME FilterProvider pipeline as a manual
  /// filter selection, so AI search can never bypass or duplicate the search
  /// logic itself.
  ///
  /// Note this deliberately does NOT call `PropertyProvider.runSearch`:
  /// SearchResultsScreen already runs the search from its own `initState`, so
  /// calling it here as well would fire two identical queries per submit.
  Future<void> _submitSearch(String value) async {
    final trimmed = value.trim();
    final filterProvider = Provider.of<FilterProvider>(context, listen: false);
    final recentSearches =
        Provider.of<RecentSearchesProvider>(context, listen: false);

    if (trimmed.isNotEmpty) {
      // Recorded BEFORE the AI parse, and as the RAW text the user typed — the
      // website saves at the same point, and storing the post-parse keywords
      // instead would show "villa" for a query submitted as
      // "3BHK villa under 1 crore in Dehradun". Not awaited: persistence is
      // best-effort and must never delay the search.
      recentSearches.add(trimmed);
      setState(() => _isParsingSmartQuery = true);
      final result = await _aiSearchService.parseQuery(trimmed);
      if (!mounted) return;
      setState(() => _isParsingSmartQuery = false);
      _applySmartQueryResult(result);
    } else {
      filterProvider.setSearchText(trimmed);
    }

    if (!mounted) return;
    setState(() => _suggestions = []);
    _searchFocusNode.unfocus();
    Navigator.pushNamed(context, AppConstants.searchResultsScreen);
  }

  void _applySmartQueryResult(SmartQueryResult result) {
    final filterProvider = Provider.of<FilterProvider>(context, listen: false);
    filterProvider.setSearchText(result.keywords);
    // Null-guarded, matching how `city` and the budget range below were already
    // handled. Without these guards an AI parse that simply didn't mention a
    // facet would CLEAR one the user had just chosen: picking the "Villa" pill
    // and then submitting free text returned `category: null`, which wiped the
    // category while leaving the subtype set — querying a residential subtype
    // with no category filter behind it.
    if (result.category != null) filterProvider.setCategory(result.category);
    if (result.listingType != null) {
      filterProvider.setListingType(result.listingType);
    }
    if (result.bhk != null) filterProvider.setBhk(result.bhk);
    if (result.city != null && result.city!.isNotEmpty) {
      filterProvider.setCities([result.city!]);
    }
    if (result.budgetMin != null || result.budgetMax != null) {
      filterProvider.setBudgetRange(RangeValues(
        result.budgetMin ?? AppConstants.priceMin,
        result.budgetMax ?? AppConstants.priceMax,
      ));
    }
  }

  Future<void> _toggleVoiceSearch() async {
    if (_isListening) {
      await _voiceSearchService.stopListening();
      if (mounted) setState(() => _isListening = false);
      return;
    }

    final started = await _voiceSearchService.startListening(
      onResult: (text, isFinal) {
        if (!mounted) return;
        _searchController.text = text;
        _searchController.selection =
            TextSelection.collapsed(offset: text.length);
        _onQueryChanged(text);
        setState(() {});
        if (isFinal) {
          setState(() => _isListening = false);
          if (text.trim().isNotEmpty) {
            _submitSearch(text);
          }
        }
      },
    );

    if (!mounted) return;
    if (started) {
      setState(() => _isListening = true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Voice search is not available on this device.'),
        ),
      );
    }
  }

  void _onSuggestionTap(GlobalSearchSuggestion suggestion) {
    if (suggestion.type == 'property') {
      Navigator.pushNamed(
        context,
        AppConstants.propertyDetailScreen,
        arguments: {'propertyId': suggestion.id},
      );
      return;
    }

    // city suggestion
    _searchController.text = suggestion.label;
    final filterProvider = Provider.of<FilterProvider>(context, listen: false);
    // Picking a city IS a committed search, so it joins the recent list under
    // the city's own name — matching the website, which calls
    // saveRecentSearch(suggestion.label) on this same branch.
    Provider.of<RecentSearchesProvider>(context, listen: false)
        .add(suggestion.label);
    filterProvider.setSearchText('');
    filterProvider.setCities([suggestion.label]);
    setState(() => _suggestions = []);
    _searchFocusNode.unfocus();
    Navigator.pushNamed(context, AppConstants.searchResultsScreen);
  }

  void _clearSearch() {
    _searchController.clear();
    _debounce?.cancel();
    Provider.of<FilterProvider>(context, listen: false).setSearchText('');
    setState(() => _suggestions = []);
  }

  /// Selecting a pill sets category + subtype together; tapping the selected
  /// pill again clears both, mirroring the redesign's own toggle behaviour.
  void _onPropertyTypeTap(_PropertyTypeOption option, bool isSelected) {
    final filterProvider = Provider.of<FilterProvider>(context, listen: false);

    if (isSelected) {
      // Deselecting clears the facet and stays put. Tapping the active pill off
      // is the user narrowing their choice on this screen, not committing to a
      // search — navigating away would make the selection impossible to undo
      // without coming back and tapping it again.
      filterProvider.setCategory(null);
      filterProvider.setSubtype(null);
      return;
    }

    // `FilterProvider.searchText` outlives this screen, so a query from an
    // earlier search is still sitting in it. Selecting a property type with an
    // empty field means "show me this type", not "show me this type matching
    // whatever I typed ten minutes ago" — so the stale term goes before the
    // facet is applied.
    //
    // Guarded rather than unconditional even though the pill row only renders
    // while the field is empty (see the `isQueryNotEmpty` branch in build), so
    // that the rule still holds — and a half-typed query is still respected —
    // if the pills ever become visible during typing.
    if (_searchController.text.trim().isEmpty) {
      filterProvider.setSearchText('');
    }

    filterProvider.setCategory(option.category);
    filterProvider.setSubtype(option.subtype);
    // Selecting IS a committed search, so it ends the same way every other
    // committed search on this screen does — by pushing the results route.
    // SearchResultsScreen.initState stays the single place runSearch is called
    // from; this deliberately does not run the query itself.
    Navigator.pushNamed(context, AppConstants.searchResultsScreen);
  }

  @override
  Widget build(BuildContext context) {
    final bool isQueryNotEmpty = _searchController.text.isNotEmpty;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(context),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: AppConstants.spacingL),
                    _buildHeading(),
                    const SizedBox(height: 18),
                    _buildSearchBar(),
                    if (_isParsingSmartQuery) ...[
                      const SizedBox(height: AppConstants.spacingS),
                      const Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: AppConstants.spacingXL),
                        child: LinearProgressIndicator(
                          minHeight: 2,
                          color: AppColors.primary,
                        ),
                      ),
                    ],
                    if (isQueryNotEmpty)
                      _buildSuggestions()
                    else ...[
                      const SizedBox(height: 22),
                      _buildPropertyTypeSection(),
                      const SizedBox(height: 26),
                      _buildRecentSearches(),
                    ],
                    const SizedBox(height: 100),
                  ],
                )
                    .animate()
                    .fadeIn(duration: 400.ms)
                    .slideY(
                      begin: 0.08,
                      end: 0,
                      duration: 400.ms,
                      curve: Curves.easeOut,
                    ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: const BottomNavBar(
        currentIndex: 1,
      ),
    );
  }

  /// Restyled to the redesign's header language — a 36 dp white circular back
  /// button, a 17/700 title, and 36 dp circular trailing actions with the
  /// primary one filled — while keeping every action and every navigation
  /// behaviour this screen already had. The former "Smart Search" toggle is
  /// gone because AI parsing is now unconditional (see [_submitSearch]); there
  /// is no longer anything for it to toggle.
  Widget _buildAppBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppConstants.spacingXL,
        vertical: 14,
      ),
      child: Row(
        children: [
          _buildAppBarCircleButton(
            icon: Icons.arrow_back,
            iconColor: AppColors.textPrimary,
            background: AppColors.cardBackground,
            withShadow: true,
            semanticLabel: 'Back',
            onTap: () {
              if (Navigator.of(context).canPop()) {
                Navigator.pop(context);
              } else {
                Provider.of<NavigationProvider>(context, listen: false)
                    .setIndex(0);
                Navigator.popUntil(context, (route) => route.isFirst);
              }
            },
          ),
          const SizedBox(width: AppConstants.spacingM),
          Expanded(
            child: Text(
              'Search',
              style: AppTextStyles.heading2.copyWith(
                fontSize: 17,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          _buildAppBarCircleButton(
            icon: Icons.map_outlined,
            iconColor: Colors.white,
            background: AppColors.primary,
            withShadow: false,
            semanticLabel: 'View results on map',
            onTap: () => Navigator.pushNamed(
              context,
              AppConstants.searchResultsScreen,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBarCircleButton({
    required IconData icon,
    required Color iconColor,
    required Color background,
    required bool withShadow,
    required String semanticLabel,
    required VoidCallback onTap,
  }) {
    return Semantics(
      label: semanticLabel,
      button: true,
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Container(
          width: _kAppBarButtonSize,
          height: _kAppBarButtonSize,
          decoration: BoxDecoration(
            color: background,
            borderRadius: BorderRadius.circular(AppConstants.pillRadius),
            boxShadow: withShadow ? AppColors.surfaceCardShadow : null,
          ),
          child: Icon(icon, size: 20, color: iconColor),
        ),
      ),
    );
  }

  Widget _buildHeading() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppConstants.spacingXL),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Search Properties',
            style: AppTextStyles.heading2.copyWith(
              fontSize: 19,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            'Find your perfect home with AI-powered search',
            style: AppTextStyles.caption.copyWith(fontSize: 12.5),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppConstants.spacingXL),
      child: SearchBarWidget(
        hint: _isListening
            ? 'Listening…'
            : 'Try "3BHK villa under 1 crore in Dehradun"',
        onTap: null,
        controller: _searchController,
        focusNode: _searchFocusNode,
        height: AppConstants.searchBarHeight,
        borderRadius: _kEntryBarRadius,
        boxShadow: AppColors.surfaceCardShadow,
        // Redesign spec for this bar: `padding: 0 8px 0 16px` with a 10 px gap
        // between the icon, the field and the mic badge.
        leadingPadding: AppConstants.spacingL,
        trailingPadding: AppConstants.spacingS,
        iconGap: _kEntryBarGap,
        trailingGap: _kEntryBarGap,
        onChanged: (val) {
          _onQueryChanged(val);
          setState(() {});
        },
        onSubmitted: _submitSearch,
        onClear: _clearSearch,
        trailing: _buildMicBadge(),
      ),
    );
  }

  /// The redesign's gradient mic badge. Listening is signalled by the filled
  /// mic glyph (and by the search field's "Listening…" hint) — the richer
  /// listening/processing treatments are Phase 7's scope.
  Widget _buildMicBadge() {
    return Semantics(
      label: _isListening ? 'Stop voice search' : 'Start voice search',
      button: true,
      child: GestureDetector(
        onTap: _toggleVoiceSearch,
        behavior: HitTestBehavior.opaque,
        child: Container(
          width: _kMicBadgeSize,
          height: _kMicBadgeSize,
          decoration: BoxDecoration(
            gradient: AppColors.primaryGradient,
            borderRadius: BorderRadius.circular(_kMicBadgeRadius),
            boxShadow: AppColors.primaryGlow,
          ),
          child: Icon(
            _isListening ? Icons.mic : Icons.mic_none,
            color: Colors.white,
            size: 19,
          ),
        ),
      ),
    );
  }

  Widget _buildPropertyTypeSection() {
    return Consumer<FilterProvider>(
      builder: (context, filterProvider, child) {
        return Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: AppConstants.spacingXL),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(
                    Icons.auto_awesome,
                    size: 14,
                    color: AppColors.primary,
                  ),
                  const SizedBox(width: 7),
                  Text(
                    'Search by property type',
                    style: AppTextStyles.caption.copyWith(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: AppConstants.spacingS,
                runSpacing: AppConstants.spacingS,
                children: [
                  for (final option in _kPropertyTypes)
                    _buildPropertyTypePill(
                      option,
                      filterProvider.category == option.category &&
                          filterProvider.subtype == option.subtype,
                    ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPropertyTypePill(_PropertyTypeOption option, bool isSelected) {
    return Semantics(
      label: option.label,
      button: true,
      selected: isSelected,
      child: GestureDetector(
        onTap: () => _onPropertyTypeTap(option, isSelected),
        behavior: HitTestBehavior.opaque,
        child: Container(
          height: AppConstants.filterChipHeight,
          padding:
              const EdgeInsets.symmetric(horizontal: AppConstants.spacingL),
          decoration: BoxDecoration(
            color:
                isSelected ? AppColors.primary : AppColors.background,
            borderRadius: BorderRadius.circular(AppConstants.pillRadius),
          ),
          child: Center(
            child: Text(
              option.label,
              style: AppTextStyles.chip.copyWith(
                color: isSelected ? Colors.white : AppColors.textSecondary,
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Real, persisted recent searches. Tapping a row re-runs that search (which
  /// also lifts it back to the top of the list); the trailing button removes
  /// just that entry.
  Widget _buildRecentSearches() {
    return Consumer<RecentSearchesProvider>(
      builder: (context, recentSearches, child) {
        final queries = recentSearches.queries;

        return Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: AppConstants.spacingXL),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSectionLabel('RECENT SEARCHES'),
              const SizedBox(height: 10),
              // Animates the collapse when a row is removed, so the rows below
              // slide up instead of jumping.
              AnimatedSize(
                duration: const Duration(milliseconds: 200),
                curve: Curves.easeOut,
                alignment: Alignment.topCenter,
                child: queries.isEmpty
                    ? Text(
                        'Your recent searches will appear here.',
                        style: AppTextStyles.caption.copyWith(fontSize: 12.5),
                      )
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          for (final query in queries)
                            _buildRecentSearchRow(query, recentSearches),
                        ],
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildRecentSearchRow(
    String query,
    RecentSearchesProvider recentSearches,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppConstants.spacingS),
      child: Semantics(
        label: query,
        button: true,
        child: GestureDetector(
          onTap: () => _onRecentSearchTap(query),
          behavior: HitTestBehavior.opaque,
          child: Container(
            height: _kRecentRowHeight,
            padding: const EdgeInsets.only(
              left: _kRecentRowPadding,
              right: AppConstants.spacingXS,
            ),
            decoration: BoxDecoration(
              color: AppColors.cardBackground,
              borderRadius: BorderRadius.circular(AppConstants.buttonRadius),
              boxShadow: AppColors.surfaceCardShadow,
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.search,
                  size: 18,
                  color: AppColors.textSecondary,
                ),
                const SizedBox(width: _kEntryBarGap),
                Expanded(
                  child: Text(
                    query,
                    style: AppTextStyles.body.copyWith(fontSize: 13),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Semantics(
                  label: 'Remove $query from recent searches',
                  button: true,
                  child: GestureDetector(
                    // Opaque so the row's own tap handler cannot swallow this.
                    behavior: HitTestBehavior.opaque,
                    onTap: () => recentSearches.remove(query),
                    child: const SizedBox(
                      width: 34,
                      height: _kRecentRowHeight,
                      child: Icon(
                        Icons.close,
                        size: 16,
                        color: AppColors.textHint,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Re-runs a stored search through the normal commit path, so it picks up AI
  /// parsing and the recent-list refresh exactly as a freshly typed query does.
  void _onRecentSearchTap(String query) {
    _searchController.text = query;
    _searchController.selection =
        TextSelection.collapsed(offset: query.length);
    _submitSearch(query);
  }

  /// The uppercase micro-label used for both the recent-searches and
  /// suggestion-group headings.
  Widget _buildSectionLabel(String text) {
    return Text(
      text,
      style: AppTextStyles.caption.copyWith(
        fontSize: 11.5,
        fontWeight: FontWeight.w600,
        color: AppColors.textHint,
        letterSpacing: 0.6,
      ),
    );
  }

  Widget _buildSuggestions() {
    if (_isLoadingSuggestions) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: AppConstants.spacingXXL),
        child: Center(child: CircularProgressIndicator()),
      );
    }

    if (_suggestions.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppConstants.spacingXL,
          vertical: AppConstants.spacingXXL,
        ),
        child: Text(
          _searchController.text.trim().length < 3
              ? 'Keep typing to see suggestions…'
              : 'Press search to look for "${_searchController.text}".',
          style: AppTextStyles.caption,
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final group in _kSuggestionGroups) ..._buildSuggestionGroup(group),
      ],
    ).animate().fadeIn(duration: 180.ms);
  }

  /// Renders one type's heading and rows, or nothing at all when this fetch
  /// returned no results of that type — an empty heading would otherwise imply
  /// a category that simply has no matches.
  List<Widget> _buildSuggestionGroup(_SuggestionGroup group) {
    final matches = _suggestions.where((s) => s.type == group.type).toList();
    if (matches.isEmpty) return const [];

    return [
      Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppConstants.spacingXL,
          vertical: AppConstants.spacingS,
        ),
        child: _buildSectionLabel(group.label),
      ),
      for (final suggestion in matches)
        Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: AppConstants.spacingXL),
          child: ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(group.icon, color: AppColors.primary),
            title: Text(suggestion.label),
            subtitle: suggestion.description != null
                ? Text(suggestion.description!)
                : null,
            onTap: () => _onSuggestionTap(suggestion),
          ),
        ),
    ];
  }
}
