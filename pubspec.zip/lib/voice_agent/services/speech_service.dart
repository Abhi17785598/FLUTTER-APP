import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'openai_proxy.dart';

// ── Silence-detection constants (matching website's speechService.ts) ────────
const double _kSilenceThresholdDb = -40.0; // dBFS; ≈ RMS 0.012 on website
const int _kSilenceHoldMs = 1500; // ms of silence before auto-stop
const int _kMaxDurationMs = 15000; // hard cap on recording length
const int _kMinSpeechMs = 400; // ignore accidental taps < 400 ms

class SpeechService {
  static final SpeechService _instance = SpeechService._internal();
  factory SpeechService() => _instance;
  SpeechService._internal();

  // ── M1: TTS fields ────────────────────────────────────────────────────────
  final AudioPlayer _player = AudioPlayer();
  bool _isTtsEnabled = false;
  bool _isSpeaking = false;
  Completer<void>? _playCompleter;

  // ── M2: STT fields ────────────────────────────────────────────────────────
  final AudioRecorder _recorder = AudioRecorder();
  bool _isListening = false;
  DateTime? _recordingStartedAt;
  DateTime? _silenceSince;
  Timer? _amplitudeTimer;
  void Function(String)? _onResult;
  void Function(String)? _onError;

  // ── Public state ──────────────────────────────────────────────────────────
  bool get isTtsEnabled => _isTtsEnabled;
  bool get isSpeaking => _isSpeaking;
  bool get isListening => _isListening;

  // ─────────────────────────────────────────────────────────────────────────
  // M1 — TTS API
  // ─────────────────────────────────────────────────────────────────────────

  void setTtsEnabled(bool value) => _isTtsEnabled = value;

  /// Synthesizes [text] via openai-proxy/audio/speech and plays it.
  /// Resolves when playback ends or [cancelSpeech] is called.
  /// Never throws — TTS is non-critical.
  Future<void> speak(String text) async {
    if (!_isTtsEnabled || text.trim().isEmpty) return;
    cancelSpeech();

    try {
      final response = await http.post(
        Uri.parse(OpenAiProxy.proxyUrl('/audio/speech')),
        headers: OpenAiProxy.jsonHeaders(),
        body: jsonEncode({'input': text, 'response_format': 'mp3'}),
      );

      if (response.statusCode < 200 || response.statusCode >= 300) {
        debugPrint('[SpeechService] TTS failed (${response.statusCode})');
        return;
      }

      _isSpeaking = true;
      _playCompleter = Completer<void>();

      // Resolve when audio ends naturally.
      _player.onPlayerComplete.first
          .then((_) => _resolvePlay())
          .catchError((_) => _resolvePlay());

      await _player.play(BytesSource(response.bodyBytes));
      await _playCompleter!.future;
    } catch (e) {
      debugPrint('[SpeechService] TTS error: $e');
    } finally {
      _isSpeaking = false;
      _playCompleter = null;
    }
  }

  /// Stops any in-progress TTS audio immediately.
  void cancelSpeech() {
    _resolvePlay(); // unblocks speak() if awaiting
    _player.stop();
    _isSpeaking = false;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // M2 — STT API
  // ─────────────────────────────────────────────────────────────────────────

  /// Records from the microphone and transcribes via
  /// openai-proxy/audio/transcriptions (OpenAI Whisper).
  ///
  /// Transcription fires automatically when silence is detected or the
  /// 15-second hard cap is reached.
  ///
  /// [onResult] receives the final trimmed transcript.
  /// [onError]  receives a user-visible error string.
  Future<void> startRecording({
    required void Function(String transcript) onResult,
    required void Function(String error) onError,
  }) async {
    if (_isListening) return;

    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) {
      onError('Microphone permission denied.');
      return;
    }

    _onResult = onResult;
    _onError = onError;
    _isListening = true;
    _recordingStartedAt = DateTime.now();
    _silenceSince = null;

    final dir = await getTemporaryDirectory();
    // OGG/Opus: record 7.1.1 has no WebM encoder on Android; opus produces
    // OGG container (confirmed in OpusFormat.kt). Whisper supports ogg natively.
    // The proxy renames to "audio.webm" but passes the Blob type through;
    // Whisper detects the actual OGG bytes regardless of the filename.
    final tempPath = '${dir.path}/va_recording.ogg';

    try {
      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.opus,
          sampleRate: 16000,
          numChannels: 1,
        ),
        path: tempPath,
      );
    } catch (e) {
      _isListening = false;
      _onResult = null;
      _onError = null;
      onError('Could not access the microphone: $e');
      return;
    }

    // Hard-cap: auto-stop after _kMaxDurationMs.
    Future.delayed(const Duration(milliseconds: _kMaxDurationMs), () {
      if (_isListening) unawaited(stopRecording());
    });

    // Amplitude-based silence detection — own Timer avoids the record package's
    // single-subscription StreamController, which cannot be re-listened after
    // the first subscription is cancelled (StateError on 2nd+ recording).
    _amplitudeTimer = Timer.periodic(
      const Duration(milliseconds: 100),
      (_) async {
        if (!_isListening) return;
        final amp = await _recorder.getAmplitude();
        _checkSilence(amp.current);
      },
    );
  }

  /// Stops recording and sends the captured audio to Whisper for transcription.
  /// [_onResult] is called with the transcript, or [_onError] on failure.
  Future<void> stopRecording() async {
    if (!_isListening) return;
    _isListening = false;

    _amplitudeTimer?.cancel();
    _amplitudeTimer = null;

    final path = await _recorder.stop();
    if (path == null || _onResult == null) return;

    await _transcribe(filePath: path);
  }

  /// Stops recording and discards the audio without transcribing.
  /// Use this when the user manually cancels input.
  Future<void> cancelRecording() async {
    _onResult = null; // cleared before stopRecording → transcription skipped
    _onError = null;

    if (!_isListening) return;
    _isListening = false;

    _amplitudeTimer?.cancel();
    _amplitudeTimer = null;

    // cancel() stops the recorder and discards/deletes the file automatically.
    await _recorder.cancel();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Private helpers
  // ─────────────────────────────────────────────────────────────────────────

  void _checkSilence(double dBfs) {
    if (!_isListening || _recordingStartedAt == null) return;

    final now = DateTime.now();
    final elapsedMs = now.difference(_recordingStartedAt!).inMilliseconds;

    if (dBfs < _kSilenceThresholdDb) {
      _silenceSince ??= now;
      final heldMs = now.difference(_silenceSince!).inMilliseconds;
      if (heldMs >= _kSilenceHoldMs && elapsedMs >= _kMinSpeechMs) {
        unawaited(stopRecording());
      }
    } else {
      _silenceSince = null;
    }
  }

  /// Uploads [filePath] as multipart/form-data to the openai-proxy STT
  /// endpoint. Matches the website request exactly:
  ///   - rawHeaders() (no Content-Type override; http sets boundary automatically)
  ///   - field 'file'     → OGG/Opus bytes, filename 'audio.ogg'
  ///   - field 'language' → 'en'
  Future<void> _transcribe({required String filePath}) async {
    // Snapshot and clear callbacks — a second call is always a no-op.
    final resultCb = _onResult;
    final errorCb = _onError;
    _onResult = null;
    _onError = null;

    try {
      final file = File(filePath);
      if (!file.existsSync()) return;
      final bytes = await file.readAsBytes();

      final request = http.MultipartRequest(
        'POST',
        Uri.parse(OpenAiProxy.proxyUrl('/audio/transcriptions')),
      )
        ..headers.addAll(OpenAiProxy.rawHeaders())
        ..files.add(http.MultipartFile.fromBytes(
          'file',
          bytes,
          filename: 'audio.ogg',
          // audio/ogg tells Deno's formData() the Blob type; Whisper accepts
          // OGG/Opus natively. The proxy renames the file to "audio.webm" but
          // preserves the Blob MIME type when forwarding to OpenAI.
          contentType: MediaType('audio', 'ogg'),
        ))
        ..fields['language'] = 'en';

      final streamed = await request.send();
      final body = await streamed.stream.bytesToString();

      if (streamed.statusCode == 401) {
        errorCb?.call(
            'AI service authorization failed. Please sign in again.');
        return;
      }
      if (streamed.statusCode == 429) {
        errorCb?.call('OpenAI rate limit reached.');
        return;
      }
      if (streamed.statusCode < 200 || streamed.statusCode >= 300) {
        final snippet = body.length > 200 ? body.substring(0, 200) : body;
        errorCb?.call(
            'Transcription error (${streamed.statusCode}): $snippet');
        return;
      }

      final decoded = jsonDecode(body) as Map<String, dynamic>;
      final text = (decoded['text'] as String? ?? '').trim();
      if (text.isEmpty) return;
      resultCb?.call(text);
    } catch (e) {
      errorCb?.call('Transcription error: $e');
    } finally {
      // Clean up the temp file regardless of outcome.
      try {
        File(filePath).deleteSync();
      } catch (_) {}
    }
  }

  void _resolvePlay() {
    if (_playCompleter != null && !_playCompleter!.isCompleted) {
      _playCompleter!.complete();
    }
  }

  void dispose() {
    cancelSpeech();
    _amplitudeTimer?.cancel();
    _player.dispose();
    _recorder.dispose();
  }
}

/// Global singleton — use this everywhere instead of instantiating directly.
final speechService = SpeechService();
