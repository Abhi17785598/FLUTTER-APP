import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// "Who viewed my profile" counts, backing the Profile screen's
/// "Profile Views" tile.
class ProfileViewService {
  final SupabaseClient _supabase = Supabase.instance.client;

  /// Unique-viewer count for [userId].
  ///
  /// Mirrors `useProfileViewCount` in hooks/useProfileViews.ts — see blueprint
  /// §9. `profile_views` holds ONE row per (owner, viewer) pair: a returning
  /// visitor bumps `view_count` instead of inserting, so the unique-viewer
  /// count is exactly the row count. React uses a head-only exact count and
  /// pulls no rows; this does the same.
  Future<int> getCount(String userId) async {
    try {
      final res = await _supabase
          .from('profile_views')
          .select('id')
          .eq('profile_user_id', userId)
          .count(CountOption.exact);

      return res.count;
    } catch (e) {
      debugPrint('ProfileViewService.getCount failed: $e');
      rethrow;
    }
  }

  // NOTE: recording a view (the `record_profile_view` RPC) is deliberately not
  // implemented here. Blueprint §9 scopes it to "when a Flutter user opens
  // someone else's profile", and the app has no other-user profile screen yet
  // — calling it from the user's own Profile screen would be wrong (React
  // no-ops self-views, server-side too).
}
