import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/available_location.dart';
import '../models/global_search_suggestion.dart';
import '../models/property_detail_bundle.dart';
import '../models/property_model.dart';
import '../models/search_query_params.dart';

/// Free-text search stopwords — exact port of Search.tsx's list. Words
/// shorter than 2 characters are dropped regardless of this set.
const Set<String> _searchStopwords = {
  'in', 'at', 'for', 'the', 'properties', 'property', 'show', 'list',
  'find', 'search', 'a', 'an', 'of', 'with',
};

/// The 5 columns Search.tsx OR-ILIKE-matches every remaining search word
/// against.
const List<String> _searchColumns = [
  'title', 'search_text', 'location', 'area', 'upid',
];

class PropertyService {
  final _supabase = Supabase.instance.client;

  Future<List<Map<String, dynamic>>> getProperties() async {
    final data = await _supabase
        .from('properties')
      .select('*,properties_residential(*),properties_commercial(*),properties_land(*)')
        .eq('status', 'active')
        .order('created_at', ascending: false);

    return List<Map<String, dynamic>>.from(data);
  }

  /// Ports Search.tsx's buildSupabaseQuery/performSearch exactly — same
  /// table, same conditional embedded-selects, same filters, same sort
  /// options. Budget is deliberately NEVER sent as a DB filter here (see
  /// the plan's Risk B): price_min/price_max are sparsely populated, so the
  /// website compares budget against the parsed free-text `price` column
  /// client-side instead — PropertyProvider does that step, not this method.
  ///
  /// [includeRange] controls whether `.range()` pagination is applied
  /// (normal list-mode paging) or a single safety-capped `.limit()` fetch is
  /// used instead (near-me / map modes, which need the whole matching set
  /// at once — see the plan's "Deliberate deviations").
  Future<PropertySearchPage> searchProperties({
    required SearchQueryParams params,
    required int offset,
    required int limit,
    bool includeRange = true,
  }) async {
    final bool postedByActive = params.postedBy != null;
    final bool bhkActive = params.bhk != null;

    final selectFields = <String>[
      '*',
      postedByActive
          ? 'user_profile:user_id!inner(display_name,user_type,company_name,avatar_url)'
          : 'user_profile:user_id(display_name,user_type,company_name,avatar_url)',
      bhkActive
          ? 'residentialDetails:properties_residential!properties_residential_property_id_fkey!inner(bedrooms,bathrooms,furnished,floor_number,total_floors)'
          : 'residentialDetails:properties_residential!properties_residential_property_id_fkey(bedrooms,bathrooms,furnished,floor_number,total_floors)',
    ];

    PostgrestFilterBuilder<PostgrestList> query = _supabase
        .from('properties')
        .select(selectFields.join(','))
        .inFilter('status', ['active', 'sold'])
        .eq('approval_status', 'approved');

    if (params.cities.length == 1) {
      query = query.ilike('location', '%${params.cities.first}%');
    } else if (params.cities.length > 1) {
      query = query.or(
        params.cities.map((c) => 'location.ilike.%$c%').join(','),
      );
    }

    if (params.category != null) {
      query = query.eq('category', params.category!);
    }
    if (params.listingType != null) {
      query = query.eq('property_type', params.listingType!);
    }
    if (params.hashtag != null && params.hashtag!.isNotEmpty) {
      query = query.contains('hashtags', [params.hashtag!]);
    }

    final searchText = params.searchText.trim();
    if (searchText.isNotEmpty) {
      final sanitized = searchText.replaceAll(RegExp(r'[,()\\]'), '');
      final words = sanitized
          .split(RegExp(r'\s+'))
          .where((w) => w.length >= 2 && !_searchStopwords.contains(w.toLowerCase()));
      final clauses = <String>[
        for (final word in words)
          for (final col in _searchColumns) '$col.ilike.%$word%',
      ];
      if (clauses.isNotEmpty) {
        query = query.or(clauses.join(','));
      }
    }

    if (params.bhk != null) {
      if (params.bhk! >= 5) {
        query = query.gte('residentialDetails.bedrooms', 5);
      } else {
        query = query.eq('residentialDetails.bedrooms', params.bhk!);
      }
    }

    if (params.subtype != null && params.subtype!.isNotEmpty) {
      query = query.ilike('residential_subtype', '%${params.subtype}%');
    }

    if (params.postedBy != null) {
      final userTypes = switch (params.postedBy) {
        'Owner' => ['individual', 'seller'],
        'Agent' => ['broker', 'dealer', 'agent'],
        'Builder' => ['builder'],
        _ => null,
      };
      if (userTypes != null) {
        query = query.inFilter('user_profile.user_type', userTypes);
      }
    }

    // .order() returns PostgrestTransformBuilder (the parent class), not
    // PostgrestFilterBuilder — all filtering above must happen before this
    // point, since nothing after can be assigned back into `query`.
    final PostgrestTransformBuilder<PostgrestList> sortedQuery = query
        .order(params.sort.column, ascending: params.sort.ascending)
        // Deterministic tiebreaker — only needed because this method paginates
        // and the website doesn't; without it, `.range()` paging across rows
        // with duplicate sort-column values could skip or repeat results.
        .order('id', ascending: true);

    final PostgrestResponse<PostgrestList> response = includeRange
        ? await sortedQuery.range(offset, offset + limit - 1).count(CountOption.exact)
        : await sortedQuery.limit(limit).count(CountOption.exact);

    return PropertySearchPage(
      rows: List<Map<String, dynamic>>.from(response.data),
      totalCount: response.count,
    );
  }

  /// Ports PropertyDetails.tsx's exact 3-query shape: the property row, its
  /// owner's profile (auth-aware column list — phone only when signed in),
  /// then exactly one of properties_land/_residential/_commercial branched
  /// on category. Reshapes into the same map shape the bulk query already
  /// produces so PropertyModel.fromSupabase is the single, shared parser for
  /// both fetch paths.
  Future<PropertyDetailBundle> getPropertyDetail(String propertyId) async {
    final Map<String, dynamic> propertyRow = await _supabase
        .from('properties')
        .select('*')
        .eq('id', propertyId)
        .single();

    final String? ownerUserId = propertyRow['user_id']?.toString();
    Map<String, dynamic>? profileRow;
    if (ownerUserId != null) {
      final bool isSignedIn = _supabase.auth.currentUser != null;
      final String profileColumns = isSignedIn
          ? 'display_name, avatar_url, user_type, phone, social_media'
          : 'display_name, avatar_url, user_type, social_media';
      profileRow = await _supabase
          .from('profiles')
          .select(profileColumns)
          .eq('user_id', ownerUserId)
          .maybeSingle();
    }

    final String? category = propertyRow['category']?.toString();
    final String? subtypeTable = switch (category) {
      'land' => 'properties_land',
      'residential' => 'properties_residential',
      'commercial' => 'properties_commercial',
      _ => null,
    };

    final Map<String, dynamic> mergedRow = {...propertyRow};
    if (subtypeTable != null) {
      final subtypeRow = await _supabase
          .from(subtypeTable)
          .select('*')
          .eq('property_id', propertyRow['id'])
          .maybeSingle();
      mergedRow[subtypeTable] = subtypeRow;
    }

    return PropertyDetailBundle(
      property: PropertyModel.fromSupabase(mergedRow),
      ownerProfile:
          profileRow != null ? PropertyOwnerProfile.fromSupabase(profileRow) : null,
    );
  }

  /// Ports RelatedPropertyCards.tsx's two-tier query: narrow-select same
  /// type+category+approved+city-substring match, falling back to a
  /// broader query (dropping the city filter) only if fewer than 4 rows
  /// came back, then de-duping and capping to 6 in that fallback branch
  /// only.
  Future<List<PropertyModel>> getRelatedProperties({
    required String propertyId,
    required String propertyType,
    required String category,
    required String location,
  }) async {
    const columns =
        'id, title, location, price, media_urls, category, property_type, area, area_unit, status, metadata';
    final cityToken = location.split(',').first.trim().toLowerCase();

    final primaryRows = List<Map<String, dynamic>>.from(await _supabase
        .from('properties')
        .select(columns)
        .eq('approval_status', 'approved')
        .eq('property_type', propertyType)
        .eq('category', category)
        .neq('id', propertyId)
        .ilike('location', '%$cityToken%')
        .limit(10));

    List<Map<String, dynamic>> rows = primaryRows;

    if (rows.length < 4) {
      final fallbackRows = List<Map<String, dynamic>>.from(await _supabase
          .from('properties')
          .select(columns)
          .eq('approval_status', 'approved')
          .eq('property_type', propertyType)
          .eq('category', category)
          .neq('id', propertyId)
          .limit(10));

      final seenIds = {for (final r in rows) r['id'].toString()};
      for (final r in fallbackRows) {
        final id = r['id']?.toString();
        if (id != null && seenIds.add(id)) {
          rows.add(r);
        }
      }
      rows = rows.where((r) => (r['title'] as String? ?? '').isNotEmpty).toList();
      if (rows.length > 6) {
        rows = rows.sublist(0, 6);
      }
    }

    return rows.map((r) => PropertyModel.fromSupabase(r)).toList();
  }

  /// Calls the `track_property_view` RPC exactly as the website does — same
  /// param names, same server-side 30-minute dedupe semantics.
  Future<bool> trackPropertyView({
    required String propertyId,
    String? viewerUserId,
    required String viewerSessionId,
    required int viewDurationSeconds,
    required int viewPercentage,
  }) async {
    final result = await _supabase.rpc('track_property_view', params: {
      'property_uuid': propertyId,
      'viewer_user_id': viewerUserId,
      'viewer_session_id': viewerSessionId,
      'view_duration': viewDurationSeconds,
      'view_percentage': viewPercentage,
    });
    return result as bool? ?? false;
  }

  Future<List<AvailableLocation>> getAvailableLocations() async {
    final rows = await _supabase
        .from('available_locations')
        .select('id,city,state,country,latitude,longitude')
        .eq('is_active', true)
        .order('display_order');

    return List<Map<String, dynamic>>.from(rows)
        .map((r) => AvailableLocation.fromSupabase(r))
        .toList();
  }

  /// Calls the `global_search` RPC used for the debounced autocomplete
  /// dropdown. See GlobalSearchSuggestion.fromSupabase for why the id field
  /// is read defensively.
  Future<List<GlobalSearchSuggestion>> globalSearch(String term) async {
    final result = await _supabase.rpc('global_search', params: {
      'search_term': term,
    });
    return List<Map<String, dynamic>>.from(result as List<dynamic>)
        .map((r) => GlobalSearchSuggestion.fromSupabase(r))
        .toList();
  }
}
