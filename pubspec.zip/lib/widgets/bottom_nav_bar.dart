import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/constants/app_constants.dart';
import '../core/theme/app_colors.dart';
import '../providers/navigation_provider.dart';
import '../providers/reels_provider.dart';
import '../screens/reels/reels_onboarding_screen.dart';
import '../screens/reels/reels_screen.dart';

class BottomNavBar extends StatelessWidget {
  final int currentIndex;
  final Function(int)? onTap;

  const BottomNavBar({
    super.key,
    required this.currentIndex,
    this.onTap,
  });

  void _defaultNavigation(BuildContext context, int index) {
    if (currentIndex == index) return;

    Provider.of<NavigationProvider>(context, listen: false).setIndex(index);

    if (index == 2) {
      // Reuse an existing ReelsScreen if one is already in the stack rather
      // than always pushing a new instance. Each ReelsScreen owns a
      // ReelControllerManager holding up to 3 live VideoPlayerControllers
      // (native video surfaces); pushing a fresh one every tap without ever
      // popping the old ones left prior instances buried (not disposed) in
      // the stack, accumulating undisposed native surfaces until the
      // Android surface buffer pool was exhausted (BLASTBufferQueue
      // "acquireNextBufferLocked: Can't acquire next buffer") and the
      // screen stopped rendering entirely.
      final navigator = Navigator.of(context);
      bool foundExisting = false;
      navigator.popUntil((route) {
        if (route.settings.name == AppConstants.reelsScreen) {
          foundExisting = true;
          return true;
        }
        return route.isFirst;
      });
      if (!foundExisting) {
        navigator.push(
          MaterialPageRoute(
            settings: const RouteSettings(name: AppConstants.reelsScreen),
            builder: (context) => const ReelsScreen(),
          ),
        );
      }
      return;
    }
    String routeName;
    switch (index) {
      case 0:
        routeName = AppConstants.homeScreen;
        break;
      case 1:
        routeName = AppConstants.searchScreen;
        break;
      case 3:
        routeName = AppConstants.profileScreen;
        break;
      default:
        routeName = AppConstants.homeScreen;
    }

    if (index == 0) {
      Navigator.popUntil(context, (route) => route.isFirst);
    } else {
      final isRoot = ModalRoute.of(context)?.isFirst ?? true;
      if (isRoot) {
        Navigator.pushNamed(context, routeName);
      } else {
        Navigator.pushReplacementNamed(context, routeName);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: AppConstants.bottomNavHeight,
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(
          top: BorderSide(
            color: AppColors.textHint,
            width: 0.5,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildNavItem(
            context: context,
            icon: Icons.home_outlined,
            activeIcon: Icons.home,
            label: 'Home',
            index: 0,
          ),
          _buildNavItem(
            context: context,
            icon: Icons.search_outlined,
            activeIcon: Icons.search,
            label: 'Search',
            index: 1,
          ),
          _buildPostPropertyButton(context),
          _buildNavItem(
            context: context,
            icon: Icons.movie_outlined,
            activeIcon: Icons.movie,
            label: 'Reels',
            index: 2,
          ),
          _buildNavItem(
            context: context,
            icon: Icons.person_outline,
            activeIcon: Icons.person,
            label: 'Profile',
            index: 3,
          ),
        ],
      ),
    );
  }

  Widget _buildPostPropertyButton(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, AppConstants.postPropertyScreen);
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 20),
        width: 56,
        height: 56,
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient,
          shape: BoxShape.circle,
          boxShadow: AppColors.primaryGlow,
        ),
        child: const Icon(
          Icons.add,
          color: Colors.white,
          size: 28,
        ),
      ),
    );
  }

  Widget _buildNavItem({
    required BuildContext context,
    required IconData icon,
    required IconData activeIcon,
    required String label,
    required int index,
  }) {
    final isActive = currentIndex == index;
    
    return GestureDetector(
      onTap: () {
        if (onTap != null) {
          onTap!(index);
        } else {
          _defaultNavigation(context, index);
        }
      },
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isActive ? activeIcon : icon,
              color: isActive ? AppColors.primary : AppColors.textSecondary,
              size: 24,
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
                color: isActive ? AppColors.primary : AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
